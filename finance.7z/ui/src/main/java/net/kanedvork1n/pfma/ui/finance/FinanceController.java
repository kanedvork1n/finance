package net.uniloftsky.pfma.ui.finance;

import net.uniloftsky.pfma.api.finance.BalanceAO;
import net.uniloftsky.pfma.api.finance.CreateFinanceOperationValidator;
import net.uniloftsky.pfma.api.finance.FinanceAPI;
import net.uniloftsky.pfma.api.finance.FinanceOperationsAO;
import net.uniloftsky.pfma.api.finance.request.CreateFinanceOperationRequest;
import net.uniloftsky.pfma.api.finance.request.FilterFinancesRequest;
import net.uniloftsky.pfma.api.shared.APIException;
import net.uniloftsky.pfma.api.shared.MonthTranslated;
import net.uniloftsky.pfma.biz.finance.IncomeCategory;
import net.uniloftsky.pfma.biz.finance.OutcomeCategory;
import net.uniloftsky.pfma.biz.finance.filter.FinanceIncomeSearchCriteria;
import net.uniloftsky.pfma.biz.finance.filter.FinanceOutcomeSearchCriteria;
import net.uniloftsky.pfma.biz.finance.filter.TimeRange;
import net.uniloftsky.pfma.biz.shared.FinanceOperationType;
import net.uniloftsky.pfma.biz.util.TimeUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Collections;
import java.util.List;

@Controller
public class FinanceController {

    private FinanceAPI financeAPI;
    private CreateFinanceOperationValidator validator;

    @GetMapping("operation")
    public String getNewOperationPage(@RequestParam("operation_type") FinanceOperationType type, @RequestParam("month") MonthTranslated month, @RequestParam("year") Integer year, Model model) {
        setNewOperationPageData(model, type, new CreateFinanceOperationRequest(), month, year);
        return "new-operation";
    }

    @PostMapping("operation")
    public String createNewOperation(@ModelAttribute("newOperation") CreateFinanceOperationRequest request, @RequestParam("month") MonthTranslated month, @RequestParam("year") Integer year, Model model, BindingResult bindingResult) throws APIException {
        validator.validate(request, bindingResult);
        if (!bindingResult.hasErrors()) {
            double amount = Double.parseDouble(request.getAmount());
            switch (request.getType()) {
                case ADD: {
                    IncomeCategory category = IncomeCategory.getById(request.getCategory());
                    financeAPI.createIncome(amount, request.getLabel(), category, month, year);
                    break;
                }
                case REMOVE: {
                    OutcomeCategory category = OutcomeCategory.getById(request.getCategory());
                    financeAPI.createOutcome(amount, request.getLabel(), category, month, year);
                    break;
                }
            }
            return "redirect:/home?month=" + month.getMonth() + "&year=" + year;
        } else {
            setNewOperationPageData(model, request.getType(), request, month, year);
            return "new-operation";
        }
    }

    @GetMapping("balance")
    public String getBalancePage(Model model) throws APIException {
        BalanceAO balance = financeAPI.getMyBalance();
        model.addAttribute("filter", new FilterFinancesRequest());
        model.addAttribute("balance", balance);
        return "balance";
    }

    @PostMapping("balance")
    public String filterBalance(@ModelAttribute("filter") FilterFinancesRequest request, Model model) throws APIException {
        TimeRange timeRange = TimeUtil.getTimeRange(request.getDateFrom(), request.getDateTo());
        BalanceAO balance = financeAPI.getMyBalance(timeRange);
        model.addAttribute("balance", balance);
        model.addAttribute("filter", request);
        return "balance";
    }

    @GetMapping("operations")
    public String getOperationsPage(@RequestParam("operation_type") FinanceOperationType type, Model model) throws APIException {
        model.addAttribute("type", type);
        model.addAttribute("filter", new FilterFinancesRequest());
        switch (type) {
            case ADD:
                model.addAttribute("chart", financeAPI.getIncomeOperations());
                model.addAttribute("categories", IncomeCategory.values());
                break;
            case REMOVE:
                model.addAttribute("chart", financeAPI.getOutcomeOperations());
                model.addAttribute("categories", OutcomeCategory.values());
                break;
        }
        return "deposit-withdrawal-pie-chart";
    }

    @PostMapping("operations")
    public String filterOperations(@RequestParam("operation_type") FinanceOperationType type, @ModelAttribute("filter") FilterFinancesRequest request, Model model) throws APIException {
        model.addAttribute("type", type);
        model.addAttribute("filter", request);
        TimeRange timeRange = TimeUtil.getTimeRange(request.getDateFrom(), request.getDateTo());
        switch (type) {
            case ADD: {
                FinanceIncomeSearchCriteria searchCriteria = new FinanceIncomeSearchCriteria(timeRange, IncomeCategory.map(request.getIncludedCategories()));
                model.addAttribute("chart", financeAPI.getIncomeOperations(searchCriteria));
                model.addAttribute("categories", IncomeCategory.values());
                break;
            }
            case REMOVE: {
                FinanceOutcomeSearchCriteria searchCriteria = new FinanceOutcomeSearchCriteria(timeRange, OutcomeCategory.map(request.getIncludedCategories()));
                model.addAttribute("chart", financeAPI.getOutcomeOperations(searchCriteria));
                model.addAttribute("categories", OutcomeCategory.values());
                break;
            }
        }
        return "deposit-withdrawal-pie-chart";
    }

    @GetMapping("operations/list")
    public String getOperationsListPage(@RequestParam("operation_type") FinanceOperationType type,
                                        @RequestParam(value = "date_from", required = false) String dateFrom,
                                        @RequestParam(value = "date_to", required = false) String dateTo,
                                        @RequestParam(value = "month", required = false) MonthTranslated month,
                                        @RequestParam(value = "year", required = false) Integer year,
                                        Model model) throws APIException {
        List<FinanceOperationsAO> operations;
        if (!StringUtils.isEmpty(dateFrom) && !StringUtils.isEmpty(dateTo)) {
            operations = financeAPI.getFinanceOperations(type, TimeUtil.getTimeRange(dateFrom, dateTo));
        } else if (month != null && year != null) {
            operations = financeAPI.getFinanceOperations(type, TimeUtil.getTimeRange(month.getMonth(), year));
        } else {
            operations = Collections.emptyList();
        }
        model.addAttribute("list", operations);
        return "deposit-withdrawal-list";
    }

    private void setNewOperationPageData(Model model, FinanceOperationType type, CreateFinanceOperationRequest newOperationRequest, MonthTranslated month, Integer year) {
        model.addAttribute("type", type);
        if (month == null && year == null) {
            model.addAttribute("timeContext", financeAPI.getTimeContext());
        } else {
            model.addAttribute("timeContext", financeAPI.getTimeContext(month, year));
        }

        model.addAttribute("newOperation", newOperationRequest);

        if (type == FinanceOperationType.ADD) {
            model.addAttribute("categories", IncomeCategory.values());
        } else {
            model.addAttribute("categories", OutcomeCategory.values());
        }
    }

    @Autowired
    public void setFinanceAPI(FinanceAPI financeAPI) {
        this.financeAPI = financeAPI;
    }

    @Autowired
    public void setValidator(CreateFinanceOperationValidator validator) {
        this.validator = validator;
    }
}
