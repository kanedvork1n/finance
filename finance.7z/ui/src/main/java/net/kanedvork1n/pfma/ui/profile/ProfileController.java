package net.uniloftsky.pfma.ui.profile;

import net.uniloftsky.pfma.api.account.AccountAPI;
import net.uniloftsky.pfma.api.account.ChangeEmailValidator;
import net.uniloftsky.pfma.api.account.request.ChangeAccountEmailRequest;
import net.uniloftsky.pfma.api.auth.AuthAPI;
import net.uniloftsky.pfma.api.auth.ChangePasswordValidator;
import net.uniloftsky.pfma.api.auth.request.ChangePasswordRequest;
import net.uniloftsky.pfma.api.profile.ProfileAPI;
import net.uniloftsky.pfma.api.shared.APIException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("profile")
public class ProfileController {

    private AccountAPI accountAPI;
    private AuthAPI authAPI;
    private ProfileAPI profileAPI;
    private ChangeEmailValidator changeEmailValidator;
    private ChangePasswordValidator changePasswordValidator;

    @GetMapping
    public String getProfilePage(Model model) throws APIException {
        setProfilePageData(model);
        return "profile";
    }

    @PostMapping("change-email")
    public String changeAccountEmail(@ModelAttribute("changeEmailRequest") ChangeAccountEmailRequest request, Model model, BindingResult bindingResult) throws APIException {
        changeEmailValidator.validate(request, bindingResult);
        if (!bindingResult.hasErrors()) {
            accountAPI.changeEmail(request.getEmail());
            model.addAttribute("emailChanged", true);
        }
        setProfilePageData(model, request);
        return "profile";
    }

    @PostMapping("change-password")
    public String changePassword(@ModelAttribute("changePasswordRequest") ChangePasswordRequest request, Model model, BindingResult bindingResult) throws APIException {
        changePasswordValidator.validate(request, bindingResult);
        if (!bindingResult.hasErrors()) {
            authAPI.updatePassword(request.getOldPassword(), request.getNewPassword());
            model.addAttribute("passwordChanged", true);
        }
        setProfilePageData(model, request);
        return "profile";
    }

    public void setProfilePageData(Model model) throws APIException {
        model.addAttribute("profile", profileAPI.getMyProfile());
        model.addAttribute("changeEmailRequest", new ChangeAccountEmailRequest());
        model.addAttribute("changePasswordRequest", new ChangePasswordRequest());
    }

    public void setProfilePageData(Model model, ChangeAccountEmailRequest request) throws APIException {
        model.addAttribute("profile", profileAPI.getMyProfile());
        model.addAttribute("changeEmailRequest", request);
        model.addAttribute("changePasswordRequest", new ChangePasswordRequest());
    }

    public void setProfilePageData(Model model, ChangePasswordRequest request) throws APIException {
        model.addAttribute("profile", profileAPI.getMyProfile());
        model.addAttribute("changeEmailRequest", new ChangeAccountEmailRequest());
        model.addAttribute("changePasswordRequest", request);
    }

    @Autowired
    public void setAccountAPI(AccountAPI accountAPI) {
        this.accountAPI = accountAPI;
    }

    @Autowired
    public void setAuthAPI(AuthAPI authAPI) {
        this.authAPI = authAPI;
    }

    @Autowired
    public void setProfileAPI(ProfileAPI profileAPI) {
        this.profileAPI = profileAPI;
    }

    @Autowired
    public void setChangeEmailValidator(ChangeEmailValidator changeEmailValidator) {
        this.changeEmailValidator = changeEmailValidator;
    }

    @Autowired
    public void setChangePasswordValidator(ChangePasswordValidator changePasswordValidator) {
        this.changePasswordValidator = changePasswordValidator;
    }
}
