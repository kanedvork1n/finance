package net.uniloftsky.pfma.ui.registration;

import net.uniloftsky.pfma.api.registration.RegisterAccountValidator;
import net.uniloftsky.pfma.api.registration.RegistrationAPI;
import net.uniloftsky.pfma.api.registration.request.RegisterAccountRequest;
import net.uniloftsky.pfma.api.shared.APIException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class RegistrationController {

    private RegisterAccountValidator registerAccountValidator;
    private RegistrationAPI registrationAPI;

    @GetMapping({"register"})
    public String getRegistrationPage(Model model) {
        model.addAttribute("request", new RegisterAccountRequest());
        return "registration";
    }

    @PostMapping({"register"})
    public String registerAccount(@ModelAttribute("request") RegisterAccountRequest registerRequest, Model model, BindingResult bindingResult) throws APIException {
        registerAccountValidator.validate(registerRequest, bindingResult);
        if (bindingResult.hasErrors()) {
            model.addAttribute("request", registerRequest);
            return "registration";
        } else {
            registrationAPI.registerAccount(registerRequest.getEmail(), registerRequest.getName(), registerRequest.getPassword());
            return "redirect:/login";
        }
    }

    @Autowired
    public void setRegisterAccountValidator(RegisterAccountValidator registerAccountValidator) {
        this.registerAccountValidator = registerAccountValidator;
    }

    @Autowired
    public void setRegistrationAPI(RegistrationAPI registrationAPI) {
        this.registrationAPI = registrationAPI;
    }
}
