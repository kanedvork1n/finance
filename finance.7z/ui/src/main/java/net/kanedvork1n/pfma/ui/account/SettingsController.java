package net.uniloftsky.pfma.ui.account;

import net.uniloftsky.pfma.api.accountsettings.AccountSettingsAO;
import net.uniloftsky.pfma.api.accountsettings.AccountSettingsAPI;
import net.uniloftsky.pfma.api.shared.APIException;
import net.uniloftsky.pfma.biz.finance.OutcomeCategory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("settings")
public class SettingsController {

    private AccountSettingsAPI accountSettingsAPI;

    @GetMapping
    public String getAccountSettingsPage(Model model) throws APIException {
        AccountSettingsAO settings = accountSettingsAPI.getAccountSettings();
        model.addAttribute("settings", settings);

        OutcomeCategory[] outcomeCategories = OutcomeCategory.values();
        model.addAttribute("outcomeCategories", outcomeCategories);
        return "settings";
    }

    @PostMapping
    public String saveAccountSettings(@ModelAttribute("settings") AccountSettingsAO settings) throws APIException {
        accountSettingsAPI.updateAccountSettings(settings);
        return "redirect:/account/settings";
    }

    @Autowired
    public void setAccountSettingsAPI(AccountSettingsAPI accountSettingsAPI) {
        this.accountSettingsAPI = accountSettingsAPI;
    }
}
