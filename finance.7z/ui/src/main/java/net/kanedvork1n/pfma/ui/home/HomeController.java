package net.uniloftsky.pfma.ui.home;

import net.uniloftsky.pfma.api.finance.BalanceAO;
import net.uniloftsky.pfma.api.finance.FinanceAPI;
import net.uniloftsky.pfma.api.finance.OutcomesAO;
import net.uniloftsky.pfma.api.finance.TimeContextAO;
import net.uniloftsky.pfma.api.shared.APIException;
import net.uniloftsky.pfma.api.shared.MonthTranslated;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {

    private FinanceAPI financeAPI;

    @GetMapping({"index", "", "/"})
    public String getIndexPage(Model model) throws APIException {
        setHomePageData(model, null, null);
        return "home";
    }

    @GetMapping({"home"})
    public String getHomePage(@RequestParam(value = "month", required = false) MonthTranslated month, @RequestParam(value = "year", required = false) Integer year, Model model) throws APIException {
        setHomePageData(model, month, year);
        return "home";
    }

    private void setHomePageData(Model model, MonthTranslated month, Integer year) throws APIException {
        OutcomesAO outcomeOperations;
        BalanceAO balance;
        TimeContextAO timeContext;
        if (month != null && year != null) {
            outcomeOperations = financeAPI.getOutcomeOperations(month, year);
            balance = financeAPI.getMyBalance(month, year);
            timeContext = financeAPI.getTimeContext(month, year);
        } else {
            outcomeOperations = financeAPI.getOutcomeOperations();
            balance = financeAPI.getMyBalance();
            timeContext = financeAPI.getTimeContext();
        }

        model.addAttribute("chart", outcomeOperations);
        model.addAttribute("icons", outcomeOperations.getIcons());
        model.addAttribute("balance", balance);
        model.addAttribute("timeContext", timeContext);
    }

    @Autowired
    public void setFinanceAPI(FinanceAPI financeAPI) {
        this.financeAPI = financeAPI;
    }
}
