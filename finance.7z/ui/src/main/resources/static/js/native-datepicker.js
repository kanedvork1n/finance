// Function to detect mobile devices
function isMobileDevice() {
    return /Mobi|Android/i.test(navigator.userAgent);
}

// Function to replace datepicker with native date input
function switchToNativeDatepicker() {
    let container = document.getElementById('datePickerContainer');
    container.removeAttribute("date-rangepicker");
    container.removeAttribute("datepicker-autohide");

    const datePickerClass = 'bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500';
    const nativeDateInputFrom = document.createElement('input');
    nativeDateInputFrom.type = 'date';
    nativeDateInputFrom.name = "dateFrom";
    nativeDateInputFrom.value = dateFrom;
    nativeDateInputFrom.className = datePickerClass;
    nativeDateInputFrom.pattern = "\d{4}-\d{2}-\d{2}";
    nativeDateInputFrom.placeholder = 'Дата від'
    container.innerHTML = '';
    container.appendChild(nativeDateInputFrom);

    const span = document.createElement("span");
    span.className = 'mx-4 text-gray-500';
    span.textContent = 'до';
    container.appendChild(span);

    const nativeDateInputTo = document.createElement('input');
    nativeDateInputTo.type = 'date';
    nativeDateInputTo.name = "dateTo";
    nativeDateInputTo.value = dateTo;
    nativeDateInputTo.className = datePickerClass;
    nativeDateInputTo.pattern = "\d{4}-\d{2}-\d{4}";
    nativeDateInputTo.placeholder = 'Дата до'
    container.appendChild(nativeDateInputTo);
}

// Check if the user is on a mobile device
if (isMobileDevice()) {
    // Replace datepicker with native date input
    switchToNativeDatepicker();
}