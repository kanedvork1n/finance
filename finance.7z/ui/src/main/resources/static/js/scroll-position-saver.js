document.querySelector('input').addEventListener('focus', (event) => {
    // Optional: Store the current scroll position
    const scrollY = window.scrollY;

    // Do something on focus
    event.target.scrollIntoView({behavior: 'smooth', block: 'center'});

    // Restore the scroll position when focus is lost
    event.target.addEventListener('blur', () => {
        window.scrollTo({top: scrollY, behavior: 'smooth'});
    }, {once: true});
});