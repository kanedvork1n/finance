package net.uniloftsky.pfma;

import net.uniloftsky.pfma.biz.account.Account;
import net.uniloftsky.pfma.biz.account.AccountService;
import net.uniloftsky.pfma.biz.account.AccountStatus;
import net.uniloftsky.pfma.biz.authentication.AuthenticationService;
import net.uniloftsky.pfma.biz.finance.FinanceService;
import net.uniloftsky.pfma.biz.finance.IncomeCategory;
import net.uniloftsky.pfma.biz.finance.OutcomeCategory;
import net.uniloftsky.pfma.biz.profile.ProfileService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class InitialDataLoader implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(InitialDataLoader.class);

    private AccountService accountService;
    private AuthenticationService authenticationService;
    private ProfileService profileService;
    private FinanceService financeService;

    @Override
    public void run(String... args) throws Exception {
        String email = "uniloftsky@gmail.com";
        String password = "123456";
        AccountStatus status = AccountStatus.REGISTERED;
        Account account = accountService.createAccount(email, status);
        authenticationService.setPassword(account.getId(), password);
        log.info("Created default account with email: {} and password: {}", email, password);

        profileService.createProfile(account.getId(), "Anton Kulyk");
        log.info("Created profile for default account with email: {}", email);

        // populating finance operations
        financeService.createIncome(account.getId(), "Зарплата", 10000, IncomeCategory.SALARY, 1714688936000L);
        financeService.createOutcome(account.getId(), "Опалення", 200, OutcomeCategory.BILLS, 1714948136000L);
        financeService.createOutcome(account.getId(), "Світло", 150, OutcomeCategory.BILLS, 1715552936000L);
        financeService.createOutcome(account.getId(), "Вода", 300, OutcomeCategory.BILLS, 1715812136000L);
    }

    @Autowired
    public void setAccountService(AccountService accountService) {
        this.accountService = accountService;
    }

    @Autowired
    public void setAuthenticationService(AuthenticationService authenticationService) {
        this.authenticationService = authenticationService;
    }

    @Autowired
    public void setProfileService(ProfileService profileService) {
        this.profileService = profileService;
    }

    @Autowired
    public void setFinanceService(FinanceService financeService) {
        this.financeService = financeService;
    }
}
