package net.uniloftsky.pfma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PfmaApplication {

    public static void main(String[] args) {
        SpringApplication.run(PfmaApplication.class, args);
    }

}
