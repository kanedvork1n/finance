package net.uniloftsky.pfma.api.profile;

import net.uniloftsky.pfma.api.shared.APIContext;
import net.uniloftsky.pfma.api.shared.APIException;
import net.uniloftsky.pfma.biz.account.Account;
import net.uniloftsky.pfma.biz.account.AccountService;
import net.uniloftsky.pfma.biz.account.AccountServiceException;
import net.uniloftsky.pfma.biz.profile.Profile;
import net.uniloftsky.pfma.biz.profile.ProfileService;
import net.uniloftsky.pfma.biz.profile.ProfileServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class ProfileAPIImpl extends APIContext implements ProfileAPI {

    private static final Logger log = LoggerFactory.getLogger(ProfileAPIImpl.class);

    private ProfileService profileService;
    private AccountService accountService;

    @Override
    public ProfileAO createProfile(UUID accountId, String fullName) throws APIException {
        try {
            Profile createdProfile = profileService.createProfile(accountId, fullName);
            return map(createdProfile);
        } catch (ProfileServiceException ex) {
            log.error("Cannot create profile for user: {}", accountId, ex);
            throw new APIException(ex.getMessage(), ex);
        }
    }

    @Override
    public ProfileAO getMyProfile() throws APIException {
        UUID currentAccountId = getCurrentAccountId();
        try {
            Profile profile = profileService.getProfile(currentAccountId);
            return map(profile);
        } catch (ProfileServiceException ex) {
            log.error("Cannot get profile for current user: {}", currentAccountId, ex);
            throw new APIException(ex.getMessage(), ex);
        }
    }

    private ProfileAO map(Profile toMap) {
        ProfileAO result = new ProfileAO();
        result.setAccountId(toMap.getAccountId());
        result.setFullName(toMap.getFullName());

        try {
            Account account = accountService.getAccountById(toMap.getAccountId());
            result.setEmail(account.getEmail());
        } catch (AccountServiceException ex) {
            log.error("Cannot get account and set email for profile", ex);
        }

        return result;
    }

    @Autowired
    public void setProfileService(ProfileService profileService) {
        this.profileService = profileService;
    }

    @Autowired
    public void setAccountService(AccountService accountService) {
        this.accountService = accountService;
    }
}
