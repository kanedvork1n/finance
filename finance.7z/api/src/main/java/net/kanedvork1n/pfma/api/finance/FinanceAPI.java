package net.uniloftsky.pfma.api.finance;

import net.uniloftsky.pfma.api.shared.APIException;
import net.uniloftsky.pfma.api.shared.MonthTranslated;
import net.uniloftsky.pfma.biz.finance.IncomeCategory;
import net.uniloftsky.pfma.biz.finance.OutcomeCategory;
import net.uniloftsky.pfma.biz.finance.filter.FinanceIncomeSearchCriteria;
import net.uniloftsky.pfma.biz.finance.filter.FinanceOutcomeSearchCriteria;
import net.uniloftsky.pfma.biz.finance.filter.TimeRange;
import net.uniloftsky.pfma.biz.shared.FinanceOperationType;

import java.util.List;

public interface FinanceAPI {

    TimeContextAO getTimeContext();

    TimeContextAO getTimeContext(MonthTranslated month, int year);

    BalanceAO getMyBalance() throws APIException;

    BalanceAO getMyBalance(MonthTranslated month, int year) throws APIException;

    BalanceAO getMyBalance(TimeRange timeRange) throws APIException;

    void createIncome(double amount, String label, IncomeCategory category, MonthTranslated month, Integer year) throws APIException;

    void createOutcome(double amount, String label, OutcomeCategory category, MonthTranslated month, Integer year) throws APIException;

    IncomesAO getIncomeOperations() throws APIException;

    IncomesAO getIncomeOperations(TimeRange timeRange) throws APIException;

    IncomesAO getIncomeOperations(FinanceIncomeSearchCriteria searchCriteria) throws APIException;

    OutcomesAO getOutcomeOperations() throws APIException;

    OutcomesAO getOutcomeOperations(TimeRange timeRange) throws APIException;

    OutcomesAO getOutcomeOperations(FinanceOutcomeSearchCriteria searchCriteria) throws APIException;

    OutcomesAO getOutcomeOperations(MonthTranslated month, int year) throws APIException;

    List<FinanceOperationsAO> getFinanceOperations(FinanceOperationType type, TimeRange timeRange) throws APIException;

}
