package net.uniloftsky.pfma.api.finance;

import java.util.ArrayList;
import java.util.List;

public class IncomesAO {

    private List<String> xAxis;
    private List<String> yAxis;
    private List<String> colors;
    private List<String> icons;

    public IncomesAO() {
        this.xAxis = new ArrayList<>();
        this.yAxis = new ArrayList<>();
        this.colors = new ArrayList<>();
        this.icons = new ArrayList<>();
    }

    public List<String> getxAxis() {
        return xAxis;
    }

    public void setxAxis(List<String> xAxis) {
        this.xAxis = xAxis;
    }

    public void addDataToXAxis(String toAdd) {
        this.xAxis.add(toAdd);
    }

    public List<String> getyAxis() {
        return yAxis;
    }

    public void setyAxis(List<String> yAxis) {
        this.yAxis = yAxis;
    }

    public void addDataToYAxis(String toAdd) {
        this.yAxis.add(toAdd);
    }

    public List<String> getColors() {
        return colors;
    }

    public void setColors(List<String> colors) {
        this.colors = colors;
    }

    public void addDataToColors(String toAdd) {
        this.colors.add(toAdd);
    }

    public List<String> getIcons() {
        return icons;
    }

    public void setIcons(List<String> icons) {
        this.icons = icons;
    }

    public void addDataToIcons(String toAdd) {
        this.icons.add(toAdd);
    }

    @Override
    public String toString() {
        return "IncomeOperationsAO{" +
                "xAxis=" + xAxis +
                ", yAxis=" + yAxis +
                '}';
    }
}
