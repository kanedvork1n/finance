package net.uniloftsky.pfma.api.auth;

import net.uniloftsky.pfma.api.shared.APIException;

public class PasswordDoesntMatchAPIException extends APIException {

    public PasswordDoesntMatchAPIException() {
    }

    public PasswordDoesntMatchAPIException(String message) {
        super(message);
    }

    public PasswordDoesntMatchAPIException(String message, Throwable cause) {
        super(message, cause);
    }
}
