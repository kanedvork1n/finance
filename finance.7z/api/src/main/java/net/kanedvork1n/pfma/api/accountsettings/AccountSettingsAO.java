package net.uniloftsky.pfma.api.accountsettings;

import java.util.UUID;

public class AccountSettingsAO {

    private UUID accountId;
    private boolean newsCheck;

    public UUID getAccountId() {
        return accountId;
    }

    public void setAccountId(UUID accountId) {
        this.accountId = accountId;
    }

    public boolean isNewsCheck() {
        return newsCheck;
    }

    public void setNewsCheck(boolean newsCheck) {
        this.newsCheck = newsCheck;
    }

    @Override
    public String toString() {
        return "AccountSettingsAO{" +
                "accountId=" + accountId +
                ", newsCheck=" + newsCheck +
                '}';
    }
}
