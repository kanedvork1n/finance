package net.uniloftsky.pfma.api.auth;

import net.uniloftsky.pfma.api.shared.APIException;

public interface AuthAPI {

    void updatePassword(String oldPassword, String newPassword) throws APIException;

}
