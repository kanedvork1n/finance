package net.uniloftsky.pfma.api.registration;

import net.uniloftsky.pfma.api.profile.ProfileAPI;
import net.uniloftsky.pfma.api.shared.APIException;
import net.uniloftsky.pfma.biz.account.Account;
import net.uniloftsky.pfma.biz.account.AccountService;
import net.uniloftsky.pfma.biz.account.AccountServiceException;
import net.uniloftsky.pfma.biz.account.AccountStatus;
import net.uniloftsky.pfma.biz.authentication.AuthenticationService;
import net.uniloftsky.pfma.biz.authentication.AuthenticationServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class RegistrationAPIImpl implements RegistrationAPI {

    private static final Logger log = LoggerFactory.getLogger(RegistrationAPIImpl.class);

    private final AccountService accountService;
    private final AuthenticationService authenticationService;
    private final ProfileAPI profileAPI;

    public RegistrationAPIImpl(AccountService accountService, AuthenticationService authenticationService, ProfileAPI profileAPI) {
        this.accountService = accountService;
        this.authenticationService = authenticationService;
        this.profileAPI = profileAPI;
    }

    @Override
    public void registerAccount(String email, String name, String password) throws APIException {
        log.info("Account would be registered with {}, {}, {}", email, name, password);

        Account account;
        try {
            account = accountService.createAccount(email, AccountStatus.REGISTERED);
        } catch (AccountServiceException ex) {
            log.error("Cannot create account with email: {}", email, ex);
            throw new APIException("Cannot register account", ex);
        }

        try {
            authenticationService.setPassword(account.getId(), password);
        } catch (AuthenticationServiceException ex) {
            log.error("Cannot set password for account with email: {}", email, ex);
        }

        profileAPI.createProfile(account.getId(), name);
    }
}
