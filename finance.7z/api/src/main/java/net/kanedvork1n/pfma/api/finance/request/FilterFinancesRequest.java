package net.uniloftsky.pfma.api.finance.request;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.List;

public class FilterFinancesRequest {

    private String dateFrom;
    private String dateTo;
    private List<Integer> includedCategories;
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public FilterFinancesRequest() {
        LocalDate now = LocalDate.now();
        LocalDate startOfMonth = now.with(TemporalAdjusters.firstDayOfMonth());
        LocalDate endOfMonth = now.with(TemporalAdjusters.lastDayOfMonth());
        this.dateFrom = startOfMonth.format(FORMATTER);
        this.dateTo = endOfMonth.format(FORMATTER);
    }

    public FilterFinancesRequest(String dateFrom, String dateTo) {
        this.dateFrom = dateFrom;
        this.dateTo = dateTo;
    }

    public String getDateFrom() {
        return dateFrom;
    }

    public void setDateFrom(String dateFrom) {
        this.dateFrom = dateFrom;
    }

    public String getDateTo() {
        return dateTo;
    }

    public void setDateTo(String dateTo) {
        this.dateTo = dateTo;
    }

    public List<Integer> getIncludedCategories() {
        return includedCategories;
    }

    public void setIncludedCategories(List<Integer> includedCategories) {
        this.includedCategories = includedCategories;
    }

    @Override
    public String toString() {
        return "FilterFinancesRequest{" +
                "dateFrom='" + dateFrom + '\'' +
                ", dateTo='" + dateTo + '\'' +
                ", includedCategories=" + includedCategories +
                '}';
    }
}
