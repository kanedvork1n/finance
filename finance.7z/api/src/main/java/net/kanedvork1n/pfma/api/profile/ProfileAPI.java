package net.uniloftsky.pfma.api.profile;

import net.uniloftsky.pfma.api.shared.APIException;

import java.util.UUID;

public interface ProfileAPI {

    ProfileAO createProfile(UUID accountId, String fullName) throws APIException;

    ProfileAO getMyProfile() throws APIException;

}
