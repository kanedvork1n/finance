package net.uniloftsky.pfma.api.accountsettings;

import net.uniloftsky.pfma.api.shared.APIException;

public interface AccountSettingsAPI {

    AccountSettingsAO getAccountSettings() throws APIException;

    AccountSettingsAO updateAccountSettings(AccountSettingsAO toUpdate) throws APIException;

}
