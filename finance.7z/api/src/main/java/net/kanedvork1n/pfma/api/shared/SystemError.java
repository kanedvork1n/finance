package net.uniloftsky.pfma.api.shared;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.validation.Errors;

public class SystemError {

    private static final Logger log = LoggerFactory.getLogger(SystemError.class);
    private static final String MESSAGE_KEY = "system.error";
    private static final String DEFAULT_MESSAGE = "Виникла система помилка :(";

    public static void notify(Errors errors, Throwable throwable) {
        log.error("System Error: {}", throwable.getMessage(), throwable);
        errors.reject(MESSAGE_KEY, DEFAULT_MESSAGE);
    }

}
