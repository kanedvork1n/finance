package net.uniloftsky.pfma.api.finance.request;

import net.uniloftsky.pfma.biz.shared.FinanceOperationType;

public class CreateFinanceOperationRequest {

    private String amount;
    private String label;
    private int category;
    private FinanceOperationType type;

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public int getCategory() {
        return category;
    }

    public void setCategory(int category) {
        this.category = category;
    }

    public FinanceOperationType getType() {
        return type;
    }

    public void setType(FinanceOperationType type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "CreateFinanceOperationRequest{" +
                "amount='" + amount + '\'' +
                ", label='" + label + '\'' +
                ", category=" + category +
                ", type=" + type +
                '}';
    }
}
