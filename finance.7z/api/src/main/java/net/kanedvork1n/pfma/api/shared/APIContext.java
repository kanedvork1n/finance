package net.uniloftsky.pfma.api.shared;

import net.uniloftsky.pfma.biz.authentication.AuthenticationUserDetails;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.UUID;

public class APIContext {

    protected UUID getCurrentAccountId() throws APIException {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication.isAuthenticated()) {
            AuthenticationUserDetails userDetails = (AuthenticationUserDetails) authentication.getPrincipal();
            return userDetails.getAccountId();
        }
        throw new APIException("No current account context");
    }

}
