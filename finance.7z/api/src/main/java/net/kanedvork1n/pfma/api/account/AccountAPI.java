package net.uniloftsky.pfma.api.account;

import net.uniloftsky.pfma.api.shared.APIException;

public interface AccountAPI {

    void changeEmail(String email) throws APIException;

}
