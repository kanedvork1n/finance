package net.uniloftsky.pfma.api.account;

import net.uniloftsky.pfma.api.shared.APIContext;
import net.uniloftsky.pfma.api.shared.APIException;
import net.uniloftsky.pfma.biz.account.Account;
import net.uniloftsky.pfma.biz.account.AccountService;
import net.uniloftsky.pfma.biz.account.AccountServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class AccountAPIImpl extends APIContext implements AccountAPI {

    private static final Logger log = LoggerFactory.getLogger(AccountAPIImpl.class);
    private AccountService accountService;

    @Override
    public void changeEmail(String email) throws APIException {
        UUID currentAccountId = getCurrentAccountId();
        try {
            Account account = accountService.getAccountById(currentAccountId);
            if (!account.getEmail().equals(email)) {
                account.setEmail(email);
                accountService.updateAccount(account);
            }
        } catch (AccountServiceException ex) {
            log.error("Cannot change email for account: {}", currentAccountId, ex);
            throw new APIException(ex.getMessage(), ex);
        }
    }

    @Autowired
    public void setAccountService(AccountService accountService) {
        this.accountService = accountService;
    }
}
