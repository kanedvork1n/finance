package net.uniloftsky.pfma.api.registration;

import net.uniloftsky.pfma.api.shared.APIException;

public class RegistrationAPIException extends APIException {

    public RegistrationAPIException() {
    }

    public RegistrationAPIException(String message) {
        super(message);
    }

    public RegistrationAPIException(String message, Throwable cause) {
        super(message, cause);
    }
}
