package net.uniloftsky.pfma.api.auth;

import net.uniloftsky.pfma.api.auth.request.ChangePasswordRequest;
import net.uniloftsky.pfma.api.shared.APIContext;
import net.uniloftsky.pfma.api.shared.APIException;
import net.uniloftsky.pfma.api.shared.ValidationMessages;
import net.uniloftsky.pfma.biz.authentication.AuthenticationService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import java.util.UUID;

@Component
public class ChangePasswordValidator extends APIContext implements Validator {

    private final AuthenticationService authenticationService;
    private final BCryptPasswordEncoder passwordEncoder;

    public ChangePasswordValidator(AuthenticationService authenticationService) {
        this.authenticationService = authenticationService;
        this.passwordEncoder = new BCryptPasswordEncoder();
    }

    @Override
    public boolean supports(Class<?> aClass) {
        return ChangePasswordRequest.class.isAssignableFrom(aClass);
    }

    @Override
    public void validate(Object o, Errors errors) {
        ChangePasswordRequest request = (ChangePasswordRequest) o;

        UUID currentAccountId;
        try {
            currentAccountId = getCurrentAccountId();
        } catch (APIException ex) {
            throw new RuntimeException(ex.getMessage(), ex);
        }

        try {
            String encodedPassword = authenticationService.getEncodedPassword(currentAccountId);
            if (!passwordEncoder.matches(request.getOldPassword(), encodedPassword)) {
                errors.rejectValue("oldPassword", ValidationMessages.PASSWORD_DOESNT_MATCH.getMessageKey(), ValidationMessages.PASSWORD_DOESNT_MATCH.getDefaultMessage());
            }
        } catch (AuthenticationServiceException ex) {
            throw new RuntimeException(ex.getMessage(), ex);
        }

        if (StringUtils.isEmpty(request.getNewPassword())) {
            errors.rejectValue("newPassword", ValidationMessages.PASSWORD_INVALID.getMessageKey(), ValidationMessages.PASSWORD_INVALID.getDefaultMessage());
        }

    }

}
