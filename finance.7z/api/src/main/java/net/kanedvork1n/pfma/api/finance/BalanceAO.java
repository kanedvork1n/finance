package net.uniloftsky.pfma.api.finance;

import java.util.List;

public class BalanceAO {

    private double balance;
    private List<String> xAxis;
    private List<String> yAxis;

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public List<String> getXAxis() {
        return xAxis;
    }

    public void setXAxis(List<String> xAxis) {
        this.xAxis = xAxis;
    }

    public List<String> getYAxis() {
        return yAxis;
    }

    public void setYAxis(List<String> yAxis) {
        this.yAxis = yAxis;
    }

    @Override
    public String toString() {
        return "BalanceAO{" +
                ", balance=" + balance +
                ", xAxis=" + xAxis +
                ", yAxis=" + yAxis +
                '}';
    }
}
