package net.uniloftsky.pfma.api.finance;

import net.uniloftsky.pfma.api.shared.APIContext;
import net.uniloftsky.pfma.api.shared.APIException;
import net.uniloftsky.pfma.api.shared.MonthTranslated;
import net.uniloftsky.pfma.biz.finance.*;
import net.uniloftsky.pfma.biz.finance.filter.FinanceIncomeSearchCriteria;
import net.uniloftsky.pfma.biz.finance.filter.FinanceOutcomeSearchCriteria;
import net.uniloftsky.pfma.biz.finance.filter.TimeRange;
import net.uniloftsky.pfma.biz.shared.FinanceOperationType;
import net.uniloftsky.pfma.biz.util.NumberFormatUtil;
import net.uniloftsky.pfma.biz.util.TimeUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.temporal.TemporalAdjusters;
import java.util.*;

import static net.uniloftsky.pfma.biz.util.TimeUtil.ZONE_ID;
import static net.uniloftsky.pfma.biz.util.TimeUtil.getTimestamp;

@Service
public class FinanceAPIImpl extends APIContext implements FinanceAPI {

    private static final Logger log = LoggerFactory.getLogger(FinanceAPIImpl.class);
    private FinanceService financeService;

    @Override
    public TimeContextAO getTimeContext() {
        LocalDateTime now = LocalDateTime.now();
        MonthTranslated month = MonthTranslated.getByMonth(now.getMonth());
        return getTimeContext(month, now.getYear());
    }

    @Override
    public TimeContextAO getTimeContext(MonthTranslated month, int year) {
        TimeContextAO result = new TimeContextAO();

        LocalDate localDateMonth = LocalDate.of(year, month.getMonth(), 1);
        MonthTranslated currentMonth = MonthTranslated.getByMonth(localDateMonth.getMonth());
        MonthTranslated nextMonth = MonthTranslated.getByMonth(localDateMonth.getMonth().plus(1));
        MonthTranslated previousMonth = MonthTranslated.getByMonth(localDateMonth.getMonth().minus(1));

        result.setCurrentMonth(currentMonth);
        result.setNextMonth(nextMonth);
        result.setPreviousMonth(previousMonth);
        result.setCurrentYear(year);
        result.setPreviousMonthYear(year);
        result.setNextMonthYear(year);
        if (currentMonth.getMonth() == Month.DECEMBER) {
            result.setNextMonthYear(year + 1);
        }
        if (currentMonth.getMonth() == Month.JANUARY) {
            result.setPreviousMonthYear(year - 1);
        }

        return result;
    }

    @Override
    public BalanceAO getMyBalance() throws APIException {
        LocalDateTime now = LocalDateTime.now();
        long startDate = now.with(TemporalAdjusters.firstDayOfMonth()).toLocalDate().atStartOfDay().atZone(ZONE_ID).toInstant().toEpochMilli();
        long endDate = now.toLocalDate().atTime(23, 59, 59, 999_999_999).atZone(ZONE_ID).toInstant().toEpochMilli();
        return getMyBalance(new TimeRange(startDate, endDate));
    }

    @Override
    public BalanceAO getMyBalance(MonthTranslated month, int year) throws APIException {
        TimeRange timeRange = TimeUtil.getTimeRange(month.getMonth(), year);
        return getMyBalance(timeRange);
    }

    @Override
    public BalanceAO getMyBalance(TimeRange timeRange) throws APIException {
        UUID currentAccountId = getCurrentAccountId();
        try {
            Balance balance = financeService.getBalance(currentAccountId, timeRange);
            return map(balance);
        } catch (FinanceServiceException ex) {
            log.error("Cannot get balance for current user: {}", currentAccountId, ex);
            throw new APIException(ex.getMessage(), ex);
        }
    }

    @Override
    public void createIncome(double amount, String label, IncomeCategory category, MonthTranslated month, Integer year) throws APIException {
        UUID currentAccountId = getCurrentAccountId();
        try {
            long creationTimestamp = getTimestamp(month.getMonth(), year);
            financeService.createIncome(currentAccountId, label, amount, category, creationTimestamp);
        } catch (FinanceServiceException ex) {
            log.error("Cannot create income for current user: {}", currentAccountId, ex);
            throw new APIException(ex.getMessage(), ex);
        }
    }

    @Override
    public void createOutcome(double amount, String label, OutcomeCategory category, MonthTranslated month, Integer year) throws APIException {
        UUID currentAccountId = getCurrentAccountId();
        try {
            long creationTimestamp = getTimestamp(month.getMonth(), year);
            financeService.createOutcome(currentAccountId, label, amount, category, creationTimestamp);
        } catch (FinanceServiceException ex) {
            log.error("Cannot create outcome for current user: {}", currentAccountId, ex);
            throw new APIException(ex.getMessage(), ex);
        }
    }

    @Override
    public IncomesAO getIncomeOperations() throws APIException {
        LocalDateTime now = LocalDateTime.now();
        long startOfMonth = now.with(TemporalAdjusters.firstDayOfMonth()).toLocalDate().atStartOfDay().atZone(ZONE_ID).toInstant().toEpochMilli();
        long endOfMonth = now.with(TemporalAdjusters.lastDayOfMonth()).toLocalDate().atTime(23, 59, 59, 999_999_999).atZone(ZONE_ID).toInstant().toEpochMilli();
        return getIncomeOperations(new TimeRange(startOfMonth, endOfMonth));
    }

    @Override
    public IncomesAO getIncomeOperations(TimeRange timeRange) throws APIException {
        UUID currentAccountId = getCurrentAccountId();
        try {
            FinanceIncomeSearchCriteria criteria = new FinanceIncomeSearchCriteria(currentAccountId, timeRange);
            List<FinanceIncomeOperation> incomes = financeService.listIncomes(criteria);
            return mapIncomes(incomes);
        } catch (FinanceServiceException ex) {
            log.error("Cannot get income operations for current account: {}", currentAccountId, ex);
            throw new APIException(ex.getMessage(), ex);
        }
    }

    @Override
    public IncomesAO getIncomeOperations(FinanceIncomeSearchCriteria searchCriteria) throws APIException {
        UUID currentAccountId = getCurrentAccountId();
        try {
            if (searchCriteria.getAccountId() == null) {
                searchCriteria.setAccountId(currentAccountId);
            }
            List<FinanceIncomeOperation> outcomes = financeService.listIncomes(searchCriteria);
            return mapIncomes(outcomes);
        } catch (FinanceServiceException ex) {
            log.error("Cannot get income operations", ex);
            throw new APIException(ex.getMessage(), ex);
        }
    }

    @Override
    public OutcomesAO getOutcomeOperations() throws APIException {
        LocalDateTime now = LocalDateTime.now();
        long startOfMonth = now.with(TemporalAdjusters.firstDayOfMonth()).toLocalDate().atStartOfDay().atZone(ZONE_ID).toInstant().toEpochMilli();
        long endOfMonth = now.with(TemporalAdjusters.lastDayOfMonth()).toLocalDate().atTime(23, 59, 59, 999_999_999).atZone(ZONE_ID).toInstant().toEpochMilli();
        return getOutcomeOperations(new TimeRange(startOfMonth, endOfMonth));
    }

    @Override
    public OutcomesAO getOutcomeOperations(TimeRange timeRange) throws APIException {
        UUID currentAccountId = getCurrentAccountId();
        try {
            FinanceOutcomeSearchCriteria criteria = new FinanceOutcomeSearchCriteria(currentAccountId, timeRange);
            List<FinanceOutcomeOperation> outcomes = financeService.listOutcomes(criteria);
            return mapOutcomes(outcomes);
        } catch (FinanceServiceException ex) {
            log.error("Cannot get outcome operations for current account: {}", currentAccountId, ex);
            throw new APIException(ex.getMessage(), ex);
        }
    }

    @Override
    public OutcomesAO getOutcomeOperations(MonthTranslated month, int year) throws APIException {
        TimeRange timeRange = TimeUtil.getTimeRange(month.getMonth(), year);
        return getOutcomeOperations(timeRange);
    }

    @Override
    public OutcomesAO getOutcomeOperations(FinanceOutcomeSearchCriteria searchCriteria) throws APIException {
        UUID currentAccountId = getCurrentAccountId();
        try {
            if (searchCriteria.getAccountId() == null) {
                searchCriteria.setAccountId(currentAccountId);
            }
            List<FinanceOutcomeOperation> outcomes = financeService.listOutcomes(searchCriteria);
            return mapOutcomes(outcomes);
        } catch (FinanceServiceException ex) {
            log.error("Cannot get outcome operations", ex);
            throw new APIException(ex.getMessage(), ex);
        }
    }

    @Override
    public List<FinanceOperationsAO> getFinanceOperations(FinanceOperationType type, TimeRange timeRange) throws APIException {
        UUID currentAccountId = getCurrentAccountId();
        List<FinanceOperationsAO> result = new ArrayList<>();
        try {
            switch (type) {
                case ADD: {
                    List<FinanceIncomeOperation> incomes = financeService.listIncomes(new FinanceIncomeSearchCriteria(currentAccountId, timeRange));
                    result = FinanceOperationsAO.build(incomes);
                    break;
                }
                case REMOVE: {
                    List<FinanceOutcomeOperation> outcomes = financeService.listOutcomes(new FinanceOutcomeSearchCriteria(currentAccountId, timeRange));
                    result = FinanceOperationsAO.build(outcomes);
                    break;
                }
                case MIXED:
                    List<FinanceIncomeOperation> incomes = financeService.listIncomes(new FinanceIncomeSearchCriteria(currentAccountId, timeRange));
                    List<FinanceOutcomeOperation> outcomes = financeService.listOutcomes(new FinanceOutcomeSearchCriteria(currentAccountId, timeRange));
                    result = FinanceOperationsAO.build(incomes, outcomes);
                    break;
            }
        } catch (FinanceServiceException ex) {
            log.error("Cannot get finance operations", ex);
            throw new APIException(ex.getMessage(), ex);
        }
        return result;
    }

    private BalanceAO map(Balance toMap) {
        BalanceAO result = new BalanceAO();
        result.setBalance(toMap.getBalance());

        Map<String, String> balanceValues = toMap.getValues();
        List<String> xAxis = new ArrayList<>(balanceValues.size());
        List<String> yAxis = new ArrayList<>(balanceValues.size());
        for (String entry : balanceValues.keySet()) {
            xAxis.add(entry);
            yAxis.add(balanceValues.get(entry));
        }

        result.setXAxis(xAxis);
        result.setYAxis(yAxis);
        return result;
    }

    private IncomesAO mapIncomes(List<FinanceIncomeOperation> operations) {
        IncomesAO result = new IncomesAO();
        Map<IncomeCategory, Double> operationsByCategory = new HashMap<>();
        for (FinanceIncomeOperation operation : operations) {
            if (!operationsByCategory.containsKey(operation.getCategory())) {
                operationsByCategory.put(operation.getCategory(), operation.getAmount());
            } else {
                Double amount = operationsByCategory.get(operation.getCategory()) + operation.getAmount();
                operationsByCategory.put(operation.getCategory(), amount);
            }
        }

        for (Map.Entry<IncomeCategory, Double> entry : operationsByCategory.entrySet()) {
            IncomeCategory category = entry.getKey();
            Double amount = entry.getValue();
            result.addDataToXAxis(category.getTranslatedName());
            result.addDataToYAxis(NumberFormatUtil.formatCurrency(amount));
            result.addDataToColors(category.getColor());
            result.addDataToIcons(category.getIcon());
        }
        return result;
    }

    private OutcomesAO mapOutcomes(List<FinanceOutcomeOperation> operations) {
        OutcomesAO result = new OutcomesAO();
        Map<OutcomeCategory, Double> operationsByCategory = new HashMap<>();
        for (FinanceOutcomeOperation operation : operations) {
            if (!operationsByCategory.containsKey(operation.getCategory())) {
                operationsByCategory.put(operation.getCategory(), operation.getAmount());
            } else {
                Double amount = operationsByCategory.get(operation.getCategory()) + operation.getAmount();
                operationsByCategory.put(operation.getCategory(), amount);
            }
        }

        for (Map.Entry<OutcomeCategory, Double> entry : operationsByCategory.entrySet()) {
            OutcomeCategory category = entry.getKey();
            Double amount = entry.getValue();
            result.addDataToXAxis(category.getTranslatedName());
            result.addDataToYAxis(NumberFormatUtil.formatCurrency(amount));
            result.addDataToColors(category.getColor());
            result.addDataToIcons(category.getIcon());
        }
        return result;
    }

    @Autowired
    public void setFinanceService(FinanceService financeService) {
        this.financeService = financeService;
    }
}
