package net.uniloftsky.pfma.api.auth;

import net.uniloftsky.pfma.api.shared.APIContext;
import net.uniloftsky.pfma.api.shared.APIException;
import net.uniloftsky.pfma.biz.authentication.AuthenticationService;
import net.uniloftsky.pfma.biz.authentication.AuthenticationServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class AuthAPIImpl extends APIContext implements AuthAPI {

    private static final Logger log = LoggerFactory.getLogger(AuthAPIImpl.class);

    private final AuthenticationService authenticationService;

    public AuthAPIImpl(AuthenticationService authenticationService) {
        this.authenticationService = authenticationService;
    }

    @Override
    public void updatePassword(String oldPassword, String newPassword) throws APIException {
        UUID currentAccountId = getCurrentAccountId();
        try {
            authenticationService.setPassword(currentAccountId, newPassword);
        } catch (AuthenticationServiceException ex) {
            log.error("Cannot update password for user: {}", currentAccountId, ex);
            throw new APIException(ex.getMessage(), ex);
        }
    }
}
