package net.uniloftsky.pfma.api.accountsettings;

import net.uniloftsky.pfma.api.shared.APIContext;
import net.uniloftsky.pfma.api.shared.APIException;
import net.uniloftsky.pfma.biz.account.AccountService;
import net.uniloftsky.pfma.biz.account.AccountServiceException;
import net.uniloftsky.pfma.biz.account.AccountSettings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class AccountSettingsAPIImpl extends APIContext implements AccountSettingsAPI {

    private static final Logger log = LoggerFactory.getLogger(AccountSettingsAPIImpl.class);
    private AccountService accountService;

    @Override
    public AccountSettingsAO getAccountSettings() throws APIException {
        UUID currentAccountId = getCurrentAccountId();
        try {
            AccountSettings settings = accountService.getAccountSettings(currentAccountId);
            return map(settings);
        } catch (AccountServiceException ex) {
            log.error("Cannot get account settings for account: {}", currentAccountId, ex);
            throw new APIException(ex.getMessage(), ex);
        }
    }

    @Override
    public AccountSettingsAO updateAccountSettings(AccountSettingsAO toUpdate) throws APIException {
        UUID currentAccountId = getCurrentAccountId();
        try {
            AccountSettings result;
            result = accountService.updateNewsCheckSetting(currentAccountId, toUpdate.isNewsCheck());
            return map(result);
        } catch (AccountServiceException ex) {
            log.error("Cannot update account settings for account: {}", currentAccountId, ex);
            throw new APIException(ex.getMessage(), ex);
        }
    }

    private AccountSettingsAO map(AccountSettings toMap) {
        AccountSettingsAO result = new AccountSettingsAO();
        result.setAccountId(toMap.getAccountId());
        result.setNewsCheck(toMap.isNewsCheck());
        return result;
    }

    @Autowired
    public void setAccountService(AccountService accountService) {
        this.accountService = accountService;
    }
}
