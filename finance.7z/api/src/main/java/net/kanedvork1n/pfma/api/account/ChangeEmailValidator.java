package net.uniloftsky.pfma.api.account;

import net.uniloftsky.pfma.api.account.request.ChangeAccountEmailRequest;
import net.uniloftsky.pfma.api.shared.APIContext;
import net.uniloftsky.pfma.api.shared.APIException;
import net.uniloftsky.pfma.api.shared.SystemError;
import net.uniloftsky.pfma.api.shared.ValidationMessages;
import net.uniloftsky.pfma.biz.account.Account;
import net.uniloftsky.pfma.biz.account.AccountNotFoundServiceException;
import net.uniloftsky.pfma.biz.account.AccountService;
import net.uniloftsky.pfma.biz.account.AccountServiceException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import java.util.UUID;

@Component
public class ChangeEmailValidator extends APIContext implements Validator {

    private final AccountService accountService;

    public ChangeEmailValidator(AccountService accountService) {
        this.accountService = accountService;
    }

    @Override
    public boolean supports(Class<?> aClass) {
        return ChangeAccountEmailRequest.class.isAssignableFrom(aClass);
    }

    @Override
    public void validate(Object o, Errors errors) {
        ChangeAccountEmailRequest request = (ChangeAccountEmailRequest) o;

        if (StringUtils.isEmpty(request.getEmail())) {
            errors.rejectValue("email", ValidationMessages.EMAIL_INVALID.getMessageKey(), ValidationMessages.EMAIL_INVALID.getDefaultMessage());
        }

        try {
            UUID currentAccountId = getCurrentAccountId();
            Account account = accountService.getAccountById(currentAccountId);
            if (!account.getEmail().equals(request.getEmail())) {
                accountService.getAccountByEmail(request.getEmail());
                errors.rejectValue("email", ValidationMessages.EMAIL_ALREADY_EXISTS.getMessageKey(), ValidationMessages.EMAIL_ALREADY_EXISTS.getDefaultMessage());
            }
        } catch (AccountNotFoundServiceException ignore) {
        } catch (AccountServiceException | APIException ex) {
            SystemError.notify(errors, ex);
        }

    }

}
