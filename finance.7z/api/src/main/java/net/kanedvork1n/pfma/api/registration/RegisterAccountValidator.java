package net.uniloftsky.pfma.api.registration;

import net.uniloftsky.pfma.api.registration.request.RegisterAccountRequest;
import net.uniloftsky.pfma.api.shared.SystemError;
import net.uniloftsky.pfma.api.shared.ValidationMessages;
import net.uniloftsky.pfma.biz.account.AccountNotFoundServiceException;
import net.uniloftsky.pfma.biz.account.AccountService;
import net.uniloftsky.pfma.biz.account.AccountServiceException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Component
public class RegisterAccountValidator implements Validator {

    private final AccountService accountService;

    public RegisterAccountValidator(AccountService accountService) {
        this.accountService = accountService;
    }

    @Override
    public boolean supports(Class<?> aClass) {
        return RegisterAccountRequest.class.isAssignableFrom(aClass);
    }

    @Override
    public void validate(Object o, Errors errors) {
        RegisterAccountRequest request = (RegisterAccountRequest) o;

        if (StringUtils.isEmpty(request.getEmail())) {
            errors.rejectValue("email", ValidationMessages.EMAIL_INVALID.getMessageKey(), ValidationMessages.EMAIL_INVALID.getDefaultMessage());
        }

        try {
            accountService.getAccountByEmail(request.getEmail());
            errors.rejectValue("email", ValidationMessages.EMAIL_ALREADY_EXISTS.getMessageKey(), ValidationMessages.EMAIL_ALREADY_EXISTS.getDefaultMessage());
        } catch (AccountNotFoundServiceException ignore) {
        } catch (AccountServiceException ex) {
            SystemError.notify(errors, ex);
        }

        if (StringUtils.isEmpty(request.getPassword())) {
            errors.rejectValue("password", ValidationMessages.PASSWORD_INVALID.getMessageKey(), ValidationMessages.PASSWORD_INVALID.getDefaultMessage());
        }

        if (StringUtils.isEmpty(request.getName())) {
            errors.rejectValue("name", ValidationMessages.NAME_INVALID.getMessageKey(), ValidationMessages.NAME_INVALID.getDefaultMessage());
        }
    }
}
