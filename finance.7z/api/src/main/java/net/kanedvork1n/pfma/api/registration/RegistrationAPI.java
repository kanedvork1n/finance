package net.uniloftsky.pfma.api.registration;

import net.uniloftsky.pfma.api.shared.APIException;

public interface RegistrationAPI {

    void registerAccount(String email, String name, String password) throws APIException;

}
