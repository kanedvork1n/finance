package net.uniloftsky.pfma.api.finance;

import net.uniloftsky.pfma.biz.finance.FinanceIncomeOperation;
import net.uniloftsky.pfma.biz.finance.FinanceOperation;
import net.uniloftsky.pfma.biz.finance.FinanceOutcomeOperation;
import net.uniloftsky.pfma.biz.shared.FinanceOperationType;
import net.uniloftsky.pfma.biz.util.NumberFormatUtil;

import java.time.Instant;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static net.uniloftsky.pfma.biz.util.TimeUtil.ZONE_ID;

public class FinanceOperationsAO {

    private String categoryTechnicalName;
    private String categoryName;
    private FinanceOperationType type;
    private String amountFormatted;
    private double amount;
    private final Set<FinanceOperationAO> list = new TreeSet<>((o1, o2) -> Long.compare(o2.getCreationTimestamp(), o1.getCreationTimestamp()));

    public static List<FinanceOperationsAO> build(List<FinanceIncomeOperation> incomes, List<FinanceOutcomeOperation> outcomes) {
        List<FinanceOperationsAO> incomeOperations = build(incomes);
        List<FinanceOperationsAO> outcomeOperations = build(outcomes);
        return Stream.concat(incomeOperations.stream(), outcomeOperations.stream()).sorted((o1, o2) -> Double.compare(o2.getAmount(), o1.getAmount())).collect(Collectors.toList());
    }

    public static <T extends FinanceOperation> List<FinanceOperationsAO> build(List<T> operations) {
        List<FinanceOperationsAO> result = new ArrayList<>();
        Map<String, List<FinanceOperation>> map = new LinkedHashMap<>();
        for (FinanceOperation operation : operations) {
            List<FinanceOperation> list;
            if (!map.containsKey(operation.getCategoryTechnicalName())) {
                list = new ArrayList<>(List.of(operation));
            } else {
                list = map.get(operation.getCategoryTechnicalName());
                list.add(operation);
            }
            map.put(operation.getCategoryTechnicalName(), list);
        }

        for (Map.Entry<String, List<FinanceOperation>> entry : map.entrySet()) {
            FinanceOperationsAO operationsByCategory = new FinanceOperationsAO();
            double amount = 0;
            FinanceOperation firstOperation = entry.getValue().get(0);
            for (FinanceOperation operation : entry.getValue()) {
                amount += operation.getAmount();
                FinanceOperationsAO.FinanceOperationAO mapped = new FinanceOperationsAO.FinanceOperationAO();
                mapped.setAmount(NumberFormatUtil.formatCurrency(operation.getAmount()));
                mapped.setLabel(operation.getLabel());
                mapped.setCreationTimestamp(operation.getCreationTimestamp());
                mapped.setDate(timestampToFormattedDate(operation.getCreationTimestamp()));
                operationsByCategory.addOperation(mapped);
            }
            operationsByCategory.setCategoryTechnicalName(firstOperation.getCategoryTechnicalName());
            operationsByCategory.setCategoryName(firstOperation.getCategoryName());
            operationsByCategory.setAmount(amount);
            operationsByCategory.setAmountFormatted(NumberFormatUtil.formatCurrency(amount));
            operationsByCategory.setType(firstOperation.getType());
            result.add(operationsByCategory);
        }
        result.sort((o1, o2) -> Double.compare(o2.getAmount(), o1.getAmount()));
        return result;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getCategoryTechnicalName() {
        return categoryTechnicalName;
    }

    public void setCategoryTechnicalName(String categoryTechnicalName) {
        this.categoryTechnicalName = categoryTechnicalName;
    }

    public FinanceOperationType getType() {
        return type;
    }

    public void setType(FinanceOperationType type) {
        this.type = type;
    }

    public String getAmountFormatted() {
        return amountFormatted;
    }

    public void setAmountFormatted(String amountFormatted) {
        this.amountFormatted = amountFormatted;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public Set<FinanceOperationAO> getList() {
        return list;
    }

    public void addOperation(FinanceOperationAO operation) {
        this.list.add(operation);
    }

    private static String timestampToFormattedDate(long timestamp) {
        LocalDate date = Instant.ofEpochMilli(timestamp).atZone(ZONE_ID).toLocalDate();
        Locale ukrainianLocale = new Locale("uk");
        int day = date.getDayOfMonth();
        String month = date.getMonth().getDisplayName(TextStyle.FULL, ukrainianLocale);
        return day + " " + month;
    }

    @Override
    public String toString() {
        return "FinanceOperationsAO{" +
                "categoryName='" + categoryName + '\'' +
                ", type=" + type +
                ", amount='" + amountFormatted + '\'' +
                ", list=" + list +
                '}';
    }

    public static class FinanceOperationAO {
        private String amount;
        private String label;
        private String date;
        private long creationTimestamp;

        public String getAmount() {
            return amount;
        }

        public void setAmount(String amount) {
            this.amount = amount;
        }

        public String getLabel() {
            return label;
        }

        public void setLabel(String label) {
            this.label = label;
        }

        public String getDate() {
            return date;
        }

        public void setDate(String date) {
            this.date = date;
        }

        public long getCreationTimestamp() {
            return creationTimestamp;
        }

        public void setCreationTimestamp(long creationTimestamp) {
            this.creationTimestamp = creationTimestamp;
        }

        @Override
        public String toString() {
            return "FinanceOperationAO{" +
                    "amount='" + amount + '\'' +
                    ", label='" + label + '\'' +
                    ", date='" + date + '\'' +
                    ", creationTimestamp=" + creationTimestamp +
                    '}';
        }
    }

}
