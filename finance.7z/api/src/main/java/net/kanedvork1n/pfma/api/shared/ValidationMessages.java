package net.uniloftsky.pfma.api.shared;

public enum ValidationMessages {

    EMAIL_INVALID("email.invalid", "Недійсна електрона пошта"),
    EMAIL_ALREADY_EXISTS("email.exists", "Електрона пошта вже використовується"),
    PASSWORD_INVALID("password.invalid", "Пароль не може бути пустим"),
    PASSWORD_DOESNT_MATCH("password.doesnt.match", "Старий пароль не співпадає"),
    NAME_INVALID("name.invalid", "ПІБ не може бути порожнім"),
    AMOUNT_INVALID("amount.invalid", "Недійсна сума");

    private final String messageKey;
    private final String defaultMessage;

    ValidationMessages(String messageKey, String defaultMessage) {
        this.messageKey = messageKey;
        this.defaultMessage = defaultMessage;
    }

    public String getMessageKey() {
        return messageKey;
    }

    public String getDefaultMessage() {
        return defaultMessage;
    }
}
