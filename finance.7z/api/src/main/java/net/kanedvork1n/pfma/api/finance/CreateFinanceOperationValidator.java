package net.uniloftsky.pfma.api.finance;

import net.uniloftsky.pfma.api.finance.request.CreateFinanceOperationRequest;
import net.uniloftsky.pfma.api.shared.ValidationMessages;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Component
public class CreateFinanceOperationValidator implements Validator {

    @Override
    public boolean supports(Class<?> aClass) {
        return CreateFinanceOperationRequest.class.isAssignableFrom(aClass);
    }

    @Override
    public void validate(Object o, Errors errors) {
        CreateFinanceOperationRequest request = (CreateFinanceOperationRequest) o;

        try {
            int amount = Integer.parseInt(request.getAmount());
            if (amount <= 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException ex) {
            errors.rejectValue("amount", ValidationMessages.AMOUNT_INVALID.getMessageKey(), ValidationMessages.AMOUNT_INVALID.getDefaultMessage());
        }
    }
}
