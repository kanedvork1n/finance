package net.uniloftsky.pfma.api.shared;

import java.time.Month;

public enum MonthTranslated {

    DECEMBER("Грудень", Month.DECEMBER),
    JANUARY("Січень", Month.JANUARY),
    FEBRUARY("Лютий", Month.FEBRUARY),
    MARCH("Березень", Month.MARCH),
    APRIL("Квітень", Month.APRIL),
    MAY("Травень", Month.MAY),
    JUNE("Червень", Month.JUNE),
    JULY("Липень", Month.JULY),
    AUGUST("Серпень", Month.AUGUST),
    SEPTEMBER("Вересень", Month.SEPTEMBER),
    OCTOBER("Жовтень", Month.OCTOBER),
    NOVEMBER("Листопад", Month.NOVEMBER);

    private final String translatedName;
    private final Month month;

    MonthTranslated(String translatedName, Month month) {
        this.translatedName = translatedName;
        this.month = month;
    }

    public String getTranslatedName() {
        return translatedName;
    }

    public Month getMonth() {
        return month;
    }

    public static MonthTranslated getByMonth(Month month) {
        MonthTranslated[] values = MonthTranslated.values();
        for (MonthTranslated value : values) {
            if (value.getMonth() == month) {
                return value;
            }
        }
        throw new IllegalArgumentException("Invalid month: " + month);
    }

    @Override
    public String toString() {
        return "MonthTranslated{" +
                "translatedName='" + translatedName + '\'' +
                '}';
    }
}
