package net.uniloftsky.pfma.api.finance;

import net.uniloftsky.pfma.api.shared.MonthTranslated;

public class TimeContextAO {

    private int previousMonthYear;
    private int currentYear;
    private int nextMonthYear;
    private MonthTranslated currentMonth;
    private MonthTranslated nextMonth;
    private MonthTranslated previousMonth;

    public int getPreviousMonthYear() {
        return previousMonthYear;
    }

    public void setPreviousMonthYear(int previousMonthYear) {
        this.previousMonthYear = previousMonthYear;
    }

    public int getCurrentYear() {
        return currentYear;
    }

    public void setCurrentYear(int currentYear) {
        this.currentYear = currentYear;
    }

    public int getNextMonthYear() {
        return nextMonthYear;
    }

    public void setNextMonthYear(int nextMonthYear) {
        this.nextMonthYear = nextMonthYear;
    }

    public MonthTranslated getCurrentMonth() {
        return currentMonth;
    }

    public void setCurrentMonth(MonthTranslated currentMonth) {
        this.currentMonth = currentMonth;
    }

    public MonthTranslated getNextMonth() {
        return nextMonth;
    }

    public void setNextMonth(MonthTranslated nextMonth) {
        this.nextMonth = nextMonth;
    }

    public MonthTranslated getPreviousMonth() {
        return previousMonth;
    }

    public void setPreviousMonth(MonthTranslated previousMonth) {
        this.previousMonth = previousMonth;
    }

    @Override
    public String toString() {
        return "TimeContextAO{" +
                "previousMonthYear=" + previousMonthYear +
                ", currentYear=" + currentYear +
                ", nextMonthYear=" + nextMonthYear +
                ", currentMonth=" + currentMonth +
                ", nextMonth=" + nextMonth +
                ", previousMonth=" + previousMonth +
                '}';
    }
}
