package net.uniloftsky.pfma.biz.finance;

import net.anotheria.idbasedlock.IdBasedLock;
import net.anotheria.idbasedlock.IdBasedLockManager;
import net.anotheria.idbasedlock.SafeIdBasedLockManager;
import net.uniloftsky.pfma.biz.finance.filter.FinanceIncomeSearchCriteria;
import net.uniloftsky.pfma.biz.finance.filter.FinanceOutcomeSearchCriteria;
import net.uniloftsky.pfma.biz.finance.filter.TimeRange;
import net.uniloftsky.pfma.biz.finance.persistence.FinanceIncomeOperationEntity;
import net.uniloftsky.pfma.biz.finance.persistence.FinanceIncomeRepository;
import net.uniloftsky.pfma.biz.finance.persistence.FinanceOutcomeOperationEntity;
import net.uniloftsky.pfma.biz.finance.persistence.FinanceOutcomeRepository;
import net.uniloftsky.pfma.biz.util.NumberFormatUtil;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import static net.uniloftsky.pfma.biz.util.TimeUtil.ZONE_ID;

@Service
public class FinanceServiceImpl implements FinanceService {

    private final FinanceIncomeRepository incomeRepository;
    private final FinanceOutcomeRepository outcomeRepository;
    private final IdBasedLockManager<UUID> lockManager;
    private final DateTimeFormatter formatter;

    public FinanceServiceImpl(FinanceIncomeRepository incomeRepository, FinanceOutcomeRepository outcomeRepository) {
        this.incomeRepository = incomeRepository;
        this.outcomeRepository = outcomeRepository;
        this.lockManager = new SafeIdBasedLockManager<>();
        this.formatter = DateTimeFormatter.ofPattern("dd.MM");
    }

    @Override
    public FinanceIncomeOperation createIncome(UUID accountId, String label, double amount, IncomeCategory category) throws FinanceServiceException {
        long currentTime = System.currentTimeMillis();
        return createIncome(accountId, label, amount, category, currentTime);
    }

    @Override
    public FinanceIncomeOperation createIncome(UUID accountId, String label, double amount, IncomeCategory category, long timestamp) throws FinanceServiceException {
        IdBasedLock<UUID> lock = lockManager.obtainLock(accountId);
        lock.lock();
        try {
            FinanceIncomeOperationEntity entity = new FinanceIncomeOperationEntity();
            entity.setId(UUID.randomUUID());
            entity.setAccountId(accountId);
            entity.setLabel(label);
            entity.setAmount(amount);
            entity.setCategory(category.getId());
            entity.setCreationTimestamp(timestamp);
            entity = incomeRepository.save(entity);
            return map(entity);
        } catch (Exception any) {
            throw new FinanceServiceException("Cannot create income for account: " + accountId);
        } finally {
            lock.unlock();
        }
    }

    @Override
    public FinanceOutcomeOperation createOutcome(UUID accountId, String label, double amount, OutcomeCategory category) throws FinanceServiceException {
        long currentTime = System.currentTimeMillis();
        return createOutcome(accountId, label, amount, category, currentTime);
    }

    @Override
    public FinanceOutcomeOperation createOutcome(UUID accountId, String label, double amount, OutcomeCategory category, long timestamp) throws FinanceServiceException {
        IdBasedLock<UUID> lock = lockManager.obtainLock(accountId);
        lock.lock();
        try {
            FinanceOutcomeOperationEntity entity = new FinanceOutcomeOperationEntity();
            entity.setId(UUID.randomUUID());
            entity.setAccountId(accountId);
            entity.setLabel(label);
            entity.setAmount(amount);
            entity.setCategory(category.getId());
            entity.setCreationTimestamp(timestamp);
            entity = outcomeRepository.save(entity);
            return map(entity);
        } catch (Exception any) {
            throw new FinanceServiceException("Cannot create outcome for account: " + accountId);
        } finally {
            lock.unlock();
        }
    }

    @Override
    public List<FinanceIncomeOperation> listIncomes(FinanceIncomeSearchCriteria searchCriteria) throws FinanceServiceException {
        try {
            List<FinanceIncomeOperationEntity> entities = incomeRepository.findAllByAccountId(searchCriteria.getAccountId());
            List<FinanceIncomeOperationEntity> filtered = new ArrayList<>(entities.size());

            // filtering incomes
            for (FinanceIncomeOperationEntity entity : entities) {
                boolean includedCategory = true;
                boolean withinTimeRange = true;
                List<IncomeCategory> includedCategories = searchCriteria.getIncludedCategories();

                if (searchCriteria.getTimeRange() != null) {
                    TimeRange timeRange = searchCriteria.getTimeRange();
                    long creationTimestamp = entity.getCreationTimestamp();
                    withinTimeRange = creationTimestamp >= timeRange.getFrom() && creationTimestamp <= timeRange.getTo();
                }
                if (!includedCategories.isEmpty()) {
                    IncomeCategory category = IncomeCategory.getById(entity.getCategory());
                    includedCategory = includedCategories.contains(category);
                }

                if (withinTimeRange && includedCategory) {
                    filtered.add(entity);
                }
            }

            return filtered.stream().map(this::map).collect(Collectors.toList());
        } catch (Exception any) {
            throw new FinanceServiceException("Cannot get list of incomes for account: " + searchCriteria.getAccountId());
        }
    }

    @Override
    public List<FinanceOutcomeOperation> listOutcomes(FinanceOutcomeSearchCriteria searchCriteria) throws FinanceServiceException {
        try {
            List<FinanceOutcomeOperationEntity> entities = outcomeRepository.findAllByAccountId(searchCriteria.getAccountId());
            List<FinanceOutcomeOperationEntity> filtered = new ArrayList<>(entities.size());

            // filtering outcomes
            for (FinanceOutcomeOperationEntity entity : entities) {
                boolean includedCategory = true;
                boolean withinTimeRange = true;
                List<OutcomeCategory> includedCategories = searchCriteria.getIncludedCategories();

                if (searchCriteria.getTimeRange() != null) {
                    TimeRange timeRange = searchCriteria.getTimeRange();
                    long creationTimestamp = entity.getCreationTimestamp();
                    withinTimeRange = creationTimestamp >= timeRange.getFrom() && creationTimestamp <= timeRange.getTo();
                }
                if (!includedCategories.isEmpty()) {
                    OutcomeCategory category = OutcomeCategory.getById(entity.getCategory());
                    includedCategory = includedCategories.contains(category);
                }

                if (withinTimeRange && includedCategory) {
                    filtered.add(entity);
                }
            }

            return filtered.stream().map(this::map).collect(Collectors.toList());
        } catch (Exception any) {
            throw new FinanceServiceException("Cannot get list of outcomes for account: " + searchCriteria.getAccountId());
        }
    }

    @Override
    public Balance getBalance(UUID accountId, TimeRange timeRange) throws FinanceServiceException {
        try {
            if (timeRange == null) {
                throw new IllegalArgumentException("TimeRange cannot be null");
            }

            Balance result = new Balance();
            double balanceAmount = getBalanceAmount(accountId, new TimeRange(0, timeRange.getTo()));
            result.setBalance(balanceAmount);

            Map<String, String> balance = new LinkedHashMap<>();
            long start = timeRange.getFrom();
            long end = timeRange.getTo();
            List<LocalDateTime> daysBetween = getDaysInRange(start, end);
            if (daysBetween.size() <= 10) {
                for (LocalDateTime day : daysBetween) {
                    FinanceDay financeDay = getFinanceDay(accountId, day);
                    balance.put(financeDay.getLabel(), financeDay.getBalance());
                }
            } else if (daysBetween.size() <= 15) {
                int counter = 1;
                for (LocalDateTime day : daysBetween) {
                    if (counter % 2 == 0 || counter == daysBetween.size()) {
                        FinanceDay financeDay = getFinanceDay(accountId, day);
                        balance.put(financeDay.getLabel(), financeDay.getBalance());
                    }
                    counter++;
                }
            } else if (daysBetween.size() <= 20) {
                int counter = 1;
                for (LocalDateTime day : daysBetween) {
                    if (counter % 4 == 0 || counter == daysBetween.size()) {
                        FinanceDay financeDay = getFinanceDay(accountId, day);
                        balance.put(financeDay.getLabel(), financeDay.getBalance());
                    }
                    counter++;
                }
            } else {
                int counter = 1;
                for (LocalDateTime day : daysBetween) {
                    if (counter % 5 == 0 || counter == daysBetween.size()) {
                        FinanceDay financeDay = getFinanceDay(accountId, day);
                        balance.put(financeDay.getLabel(), financeDay.getBalance());
                    }
                    counter++;
                }
            }

            result.setValues(balance);
            return result;
        } catch (Exception any) {
            throw new FinanceServiceException("Cannot get balance for account: " + accountId);
        }
    }

    private double getBalanceAmount(UUID accountId, TimeRange timeRange) throws FinanceServiceException {
        try {
            List<FinanceIncomeOperation> incomes = listIncomes(new FinanceIncomeSearchCriteria(accountId, timeRange));
            List<FinanceOutcomeOperation> outcomes = listOutcomes(new FinanceOutcomeSearchCriteria(accountId, timeRange));
            return calculateBalance(incomes, outcomes);
        } catch (Exception any) {
            throw new FinanceServiceException("Cannot get balance for account: " + accountId, any);
        }
    }

    private List<LocalDateTime> getDaysInRange(long from, long to) {
        List<LocalDateTime> daysList = new ArrayList<>();

        Instant startInstant = Instant.ofEpochMilli(from);
        Instant endInstant = Instant.ofEpochMilli(to);

        LocalDate startDate = startInstant.atZone(ZONE_ID).toLocalDate();
        LocalDate endDate = endInstant.atZone(ZONE_ID).toLocalDate();

        LocalDate currentDate = startDate;
        while (!currentDate.isAfter(endDate)) {
            LocalDateTime currentDateTime = currentDate.atStartOfDay();
            daysList.add(currentDateTime);
            currentDate = currentDate.plusDays(1);
        }

        return daysList;
    }

    private FinanceDay getFinanceDay(UUID accountId, LocalDateTime day) throws FinanceServiceException {
        long endOfDay = day.toLocalDate().atTime(23, 59, 59).atZone(ZONE_ID).toInstant().toEpochMilli();
        double balanceForDay = getBalanceAmount(accountId, new TimeRange(0, endOfDay));
        String dayLabel = day.format(formatter);
        String formattedBalance = NumberFormatUtil.formatCurrency(balanceForDay);
        return new FinanceDay(formattedBalance, dayLabel);
    }

    private double calculateBalance(List<FinanceIncomeOperation> incomes, List<FinanceOutcomeOperation> outcomes) {
        double balance = 0;
        for (FinanceIncomeOperation income : incomes) {
            balance += income.getAmount();
        }
        for (FinanceOutcomeOperation outcome : outcomes) {
            balance -= outcome.getAmount();
        }
        return balance;
    }

    private FinanceIncomeOperation map(FinanceIncomeOperationEntity toMap) {
        FinanceIncomeOperation result = new FinanceIncomeOperation();
        result.setId(toMap.getId());
        result.setAccountId(toMap.getAccountId());
        result.setLabel(toMap.getLabel());
        result.setAmount(toMap.getAmount());
        result.setCategory(IncomeCategory.getById(toMap.getCategory()));
        result.setCreationTimestamp(toMap.getCreationTimestamp());
        result.setUpdatedTimestamp(toMap.getUpdatedTimestamp());
        return result;
    }

    private FinanceOutcomeOperation map(FinanceOutcomeOperationEntity toMap) {
        FinanceOutcomeOperation result = new FinanceOutcomeOperation();
        result.setId(toMap.getId());
        result.setAccountId(toMap.getAccountId());
        result.setLabel(toMap.getLabel());
        result.setAmount(toMap.getAmount());
        result.setCategory(OutcomeCategory.getById(toMap.getCategory()));
        result.setCreationTimestamp(toMap.getCreationTimestamp());
        result.setUpdatedTimestamp(toMap.getUpdatedTimestamp());
        return result;
    }
}
