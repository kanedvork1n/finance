package net.uniloftsky.pfma.biz.account;

import java.util.UUID;

public interface AccountService {

    Account createAccount(String email, AccountStatus ... statuses) throws AccountServiceException;

    Account getAccountById(UUID id) throws AccountServiceException;

    Account getAccountByEmail(String email) throws AccountServiceException;

    Account updateAccount(Account toUpdate) throws AccountServiceException;

    AccountSettings getAccountSettings(UUID accountId) throws AccountServiceException;

    AccountSettings updateNewsCheckSetting(UUID accountId, boolean newsCheck) throws AccountServiceException;

}
