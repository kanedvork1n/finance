package net.uniloftsky.pfma.biz.authentication;

import net.uniloftsky.pfma.biz.account.Account;
import net.uniloftsky.pfma.biz.account.AccountService;
import net.uniloftsky.pfma.biz.account.AccountServiceException;
import net.uniloftsky.pfma.biz.authentication.persistence.AuthenticationPasswordEntity;
import net.uniloftsky.pfma.biz.authentication.persistence.AuthenticationPasswordRepository;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

@Service
public class AuthenticationServiceImpl implements AuthenticationService, UserDetailsService {

    private static final String EMPTY_PASSWORD = "";

    private final AuthenticationPasswordRepository repository;

    private final AccountService accountService;

    private final BCryptPasswordEncoder passwordEncoder;

    public AuthenticationServiceImpl(AuthenticationPasswordRepository repository, AccountService accountService) {
        this.repository = repository;
        this.accountService = accountService;
        this.passwordEncoder = new BCryptPasswordEncoder();
    }

    @Override
    public void setPassword(UUID accountId, String password) throws AuthenticationServiceException {
        try {
            String encodedPassword = passwordEncoder.encode(password);
            AuthenticationPasswordEntity entity;
            Optional<AuthenticationPasswordEntity> optionalEntity = repository.findById(accountId);
            if (optionalEntity.isEmpty()) {
                entity = new AuthenticationPasswordEntity();
                entity.setAccountId(accountId);
            } else {
                entity = optionalEntity.get();
            }
            entity.setPassword(encodedPassword);
            repository.save(entity);
        } catch (Exception any) {
            throw new AuthenticationServiceException("Cannot set password for account with id: " + accountId, any);
        }
    }

    @Override
    public String getEncodedPassword(UUID accountId) throws AuthenticationServiceException {
        try {
            Optional<AuthenticationPasswordEntity> optionalPassword = repository.findById(accountId);
            if (optionalPassword.isEmpty()) {
                return EMPTY_PASSWORD;
            }
            return optionalPassword.get().getPassword();
        } catch (Exception any) {
            throw new AuthenticationServiceException("Cannot get encoded password for account with id: " + accountId, any);
        }
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        Account account;
        try {
            account = accountService.getAccountByEmail(email);
        } catch (AccountServiceException ex) {
            throw new UsernameNotFoundException(ex.getMessage(), ex);
        }

        String password = getEncodedPassword(account.getId());
        return new AuthenticationUserDetails(account.getId(), account.getEmail(), password);
    }
}
