package net.uniloftsky.pfma.biz.account;

import java.util.Objects;
import java.util.UUID;

public class AccountSettings {

    private UUID accountId;
    private boolean newsCheck;
    private long creationTimestamp;
    private long updatedTimestamp;

    public UUID getAccountId() {
        return accountId;
    }

    public void setAccountId(UUID accountId) {
        this.accountId = accountId;
    }

    public boolean isNewsCheck() {
        return newsCheck;
    }

    public void setNewsCheck(boolean newsCheck) {
        this.newsCheck = newsCheck;
    }

    public long getCreationTimestamp() {
        return creationTimestamp;
    }

    public void setCreationTimestamp(long creationTimestamp) {
        this.creationTimestamp = creationTimestamp;
    }

    public long getUpdatedTimestamp() {
        return updatedTimestamp;
    }

    public void setUpdatedTimestamp(long updatedTimestamp) {
        this.updatedTimestamp = updatedTimestamp;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AccountSettings that = (AccountSettings) o;
        return Objects.equals(accountId, that.accountId);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(accountId);
    }

    @Override
    public String toString() {
        return "AccountSettings{" +
                "accountId=" + accountId +
                ", newsCheck=" + newsCheck +
                ", creationTimestamp=" + creationTimestamp +
                ", updatedTimestamp=" + updatedTimestamp +
                '}';
    }
}
