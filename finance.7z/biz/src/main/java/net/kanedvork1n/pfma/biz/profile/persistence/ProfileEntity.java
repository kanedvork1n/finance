package net.uniloftsky.pfma.biz.profile.persistence;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.UUID;

@Entity
@Table(name = "profile")
public class ProfileEntity {

    @Id
    @Column(name = "account_id")
    private UUID accountId;

    @Column(name = "full_name")
    private String fullName;

    @Column(name = "creation_timestamp")
    private long creationTimestamp;

    @Column(name = "updated_timestamp")
    private long updatedTimestamp;

    public UUID getAccountId() {
        return accountId;
    }

    public void setAccountId(UUID accountId) {
        this.accountId = accountId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public long getCreationTimestamp() {
        return creationTimestamp;
    }

    public void setCreationTimestamp(long createdTimestamp) {
        this.creationTimestamp = createdTimestamp;
    }

    public long getUpdatedTimestamp() {
        return updatedTimestamp;
    }

    public void setUpdatedTimestamp(long updatedTimestamp) {
        this.updatedTimestamp = updatedTimestamp;
    }

    @Override
    public String toString() {
        return "ProfileEntity{" +
                "accountId=" + accountId +
                ", fullName='" + fullName + '\'' +
                ", creationTimestamp=" + creationTimestamp +
                ", updatedTimestamp=" + updatedTimestamp +
                '}';
    }
}
