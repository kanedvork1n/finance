package net.uniloftsky.pfma.biz.account;

public class AccountAlreadyExistsServiceException extends AccountServiceException {

    public AccountAlreadyExistsServiceException() {
    }

    public AccountAlreadyExistsServiceException(String message) {
        super(message);
    }

    public AccountAlreadyExistsServiceException(String message, Throwable cause) {
        super(message, cause);
    }
}
