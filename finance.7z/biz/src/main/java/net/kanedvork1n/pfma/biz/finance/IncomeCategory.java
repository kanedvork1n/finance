package net.uniloftsky.pfma.biz.finance;

import net.uniloftsky.pfma.biz.shared.FinanceOperationType;

import java.util.ArrayList;
import java.util.List;

public enum IncomeCategory {

    SALARY(1, "https://img.icons8.com/ios/50/receive-change.png", "Зарплата", "#00FF09"),
    DEPOSITS(2, "https://img.icons8.com/ios/50/money-bag.png", "Депозити", "#00EFFF"),
    SAVING(3, "https://img.icons8.com/ios/50/money-box--v1.png", "Заощадження", "#FF00F7");

    private final int id;
    private final String icon;
    private final String color;
    private final String translatedName;
    private final FinanceOperationType categoryType;

    IncomeCategory(int id, String icon, String translatedName, String color) {
        this.id = id;
        this.icon = icon;
        this.translatedName = translatedName;
        this.color = color;
        this.categoryType = FinanceOperationType.ADD;
    }

    public int getId() {
        return id;
    }

    public String getIcon() {
        return icon;
    }

    public String getColor() {
        return color;
    }

    public String getTranslatedName() {
        return translatedName;
    }

    public FinanceOperationType getCategoryType() {
        return categoryType;
    }

    public static IncomeCategory getById(int id) {
        for (IncomeCategory category : IncomeCategory.values()) {
            if (category.getId() == id) {
                return category;
            }
        }
        throw new IllegalArgumentException("Invalid category id: " + id);
    }

    public static List<IncomeCategory> map(List<Integer> ids) {
        List<IncomeCategory> categories = new ArrayList<>(ids.size());
        for (Integer id : ids) {
            categories.add(getById(id));
        }
        return categories;
    }

    @Override
    public String toString() {
        return "IncomeCategory{" +
                "id=" + id +
                ", icon='" + icon + '\'' +
                ", color='" + color + '\'' +
                ", categoryType=" + categoryType +
                '}';
    }

}
