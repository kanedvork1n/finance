package net.uniloftsky.pfma.biz.profile;

import java.util.UUID;

public interface ProfileService {

    Profile createProfile(UUID accountId, String fullName) throws ProfileServiceException;

    Profile getProfile(UUID accountId) throws ProfileServiceException;

}
