package net.uniloftsky.pfma.biz.profile;

import net.anotheria.idbasedlock.IdBasedLock;
import net.anotheria.idbasedlock.IdBasedLockManager;
import net.anotheria.idbasedlock.SafeIdBasedLockManager;
import net.uniloftsky.pfma.biz.profile.persistence.ProfileEntity;
import net.uniloftsky.pfma.biz.profile.persistence.ProfileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

@Service
public class ProfileServiceImpl implements ProfileService {

    private ProfileRepository repository;
    private final IdBasedLockManager<UUID> lockManager;

    public ProfileServiceImpl() {
        this.lockManager = new SafeIdBasedLockManager<>();
    }

    @Override
    public Profile createProfile(UUID accountId, String fullName) throws ProfileServiceException {
        IdBasedLock<UUID> lock = lockManager.obtainLock(accountId);
        lock.lock();
        try {
            ProfileEntity entity;
            Optional<ProfileEntity> optionalProfile = repository.findById(accountId);
            if (optionalProfile.isEmpty()) {
                entity = new ProfileEntity();
                entity.setAccountId(accountId);

                long currentTime = System.currentTimeMillis();
                entity.setCreationTimestamp(currentTime);
                entity.setFullName(fullName);
                entity = repository.save(entity);
            } else {
                entity = optionalProfile.get();
            }
            return map(entity);
        } catch (Exception any) {
            throw new ProfileServiceException("Cannot create profile for account: " + accountId, any);
        } finally {
            lock.unlock();
        }
    }

    @Override
    public Profile getProfile(UUID accountId) throws ProfileServiceException {
        try {
            Optional<ProfileEntity> optionalProfile = repository.findById(accountId);
            if (optionalProfile.isPresent()) {
                return map(optionalProfile.get());
            }
            throw new ProfileNotFoundServiceException("Profile for account: " + accountId + " cannot be found");
        } catch (Exception any) {
            throw new ProfileServiceException("Cannot get profile for account: " + accountId, any);
        }
    }

    private Profile map(ProfileEntity toMap) {
        Profile result = new Profile();
        result.setAccountId(toMap.getAccountId());
        result.setFullName(toMap.getFullName());
        result.setCreatedTimestamp(toMap.getCreationTimestamp());
        result.setUpdatedTimestamp(toMap.getUpdatedTimestamp());
        return result;
    }

    @Autowired
    public void setRepository(ProfileRepository repository) {
        this.repository = repository;
    }
}
