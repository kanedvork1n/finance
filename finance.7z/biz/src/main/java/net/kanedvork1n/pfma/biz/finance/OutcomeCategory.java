package net.uniloftsky.pfma.biz.finance;

import net.uniloftsky.pfma.biz.shared.FinanceOperationType;

import java.util.ArrayList;
import java.util.List;

public enum OutcomeCategory {

    HYGIENE(1, "https://img.icons8.com/pastel-glyph/50/tooth-cleaning-kit--v3.png", "Гігієна", "#77FF00"),
    HOME(2, "https://img.icons8.com/ios/50/home--v1.png", "Домівка", "#003CFF"),
    CONNECTION(3, "https://img.icons8.com/ios/50/phone--v1.png", "Зв'язок", "#B300FF"),
    HEALTH(4, "https://img.icons8.com/external-outline-chattapat-/50/external-illness-medical-outline-chattapat-.png", "Здоров'я", "#FF0000"),
    FOOD(5, "https://img.icons8.com/ios/50/food-donor.png", "Їжа", "#FF7272"),
    CAFE(6, "https://img.icons8.com/ios/50/cutlery.png", "Кафе", "#00C120"),
    CAR(7, "https://img.icons8.com/ios/50/sedan.png", "Машина", "#3975FF"),
    CLOTHES(8, "https://img.icons8.com/ios/50/t-shirt--v1.png", "Одежа", "#A10AEC"),
    GIFTS(9, "https://img.icons8.com/ios/50/gift--v1.png", "Подарунки", "#E0A1FF"),
    BILLS(10, "https://img.icons8.com/ios/50/price-tag-usd--v1.png", "Рахунки", "#FFC400"),
    ENTERTAINMENTS(11, "https://img.icons8.com/ios/50/cocktail.png", "Розваги", "#FF9A00"),
    SPORT(12, "https://img.icons8.com/ios/50/football.png", "Спорт", "#00F7FF"),
    TAXI(13, "https://img.icons8.com/ios/50/taxi.png", "Таксі", "#FFFF00"),
    TRANSPORT(14, "https://img.icons8.com/ios/50/tram.png", "Транспорт", "#C91717"),
    PETS(15, "https://img.icons8.com/ios/50/cat--v1.png", "Улюбленці", "#00FFAB");

    private final int id;
    private final String icon;
    private final String color;
    private final String translatedName;
    private final FinanceOperationType categoryType;

    OutcomeCategory(int id, String icon, String translatedName, String color) {
        this.id = id;
        this.icon = icon;
        this.translatedName = translatedName;
        this.color = color;
        this.categoryType = FinanceOperationType.REMOVE;
    }

    public int getId() {
        return id;
    }

    public String getIcon() {
        return icon;
    }

    public String getColor() {
        return color;
    }

    public FinanceOperationType getCategoryType() {
        return categoryType;
    }

    public String getTranslatedName() {
        return translatedName;
    }

    public static OutcomeCategory getById(int id) {
        for (OutcomeCategory category : OutcomeCategory.values()) {
            if (category.getId() == id) {
                return category;
            }
        }
        throw new IllegalArgumentException("Invalid category id: " + id);
    }

    public static List<OutcomeCategory> map(List<Integer> ids) {
        List<OutcomeCategory> categories = new ArrayList<>(ids.size());
        for (Integer id : ids) {
            categories.add(getById(id));
        }
        return categories;
    }

    @Override
    public String toString() {
        return "OutcomeCategory{" +
                "id=" + id +
                ", icon='" + icon + '\'' +
                ", color='" + color + '\'' +
                ", categoryType=" + categoryType +
                '}';
    }
}
