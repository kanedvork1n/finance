package net.uniloftsky.pfma.biz.authentication.persistence;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Objects;
import java.util.UUID;

@Entity
@Table(name = "auth_password")
public class AuthenticationPasswordEntity {

    @Id
    @Column(name = "account_id")
    private UUID accountId;

    @Column(name = "password")
    private String password;

    public UUID getAccountId() {
        return accountId;
    }

    public void setAccountId(UUID accountId) {
        this.accountId = accountId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AuthenticationPasswordEntity that = (AuthenticationPasswordEntity) o;
        return Objects.equals(accountId, that.accountId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(accountId);
    }

    @Override
    public String toString() {
        return "AuthenticationPasswordEntity{" +
                "accountId=" + accountId +
                ", password='" + password + '\'' +
                '}';
    }
}
