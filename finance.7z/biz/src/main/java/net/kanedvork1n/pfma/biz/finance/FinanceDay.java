package net.uniloftsky.pfma.biz.finance;

public class FinanceDay {

    private String balance;
    private String label;

    public FinanceDay(String balance, String label) {
        this.balance = balance;
        this.label = label;
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    @Override
    public String toString() {
        return "FinanceDay{" +
                "balance=" + balance +
                ", label='" + label + '\'' +
                '}';
    }
}
