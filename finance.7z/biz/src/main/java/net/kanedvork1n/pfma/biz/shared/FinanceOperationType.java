package net.uniloftsky.pfma.biz.shared;

public enum FinanceOperationType {

    ADD, REMOVE, MIXED

}
