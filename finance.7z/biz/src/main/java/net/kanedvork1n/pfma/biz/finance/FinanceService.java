package net.uniloftsky.pfma.biz.finance;

import net.uniloftsky.pfma.biz.finance.filter.FinanceIncomeSearchCriteria;
import net.uniloftsky.pfma.biz.finance.filter.FinanceOutcomeSearchCriteria;
import net.uniloftsky.pfma.biz.finance.filter.TimeRange;

import java.util.List;
import java.util.UUID;

public interface FinanceService {

    FinanceIncomeOperation createIncome(UUID accountId, String label, double amount, IncomeCategory category) throws FinanceServiceException;

    // For internal usage only
    FinanceIncomeOperation createIncome(UUID accountId, String label, double amount, IncomeCategory category, long timestamp) throws FinanceServiceException;

    FinanceOutcomeOperation createOutcome(UUID accountId, String label, double amount, OutcomeCategory category) throws FinanceServiceException;

    // For internal usage only
    FinanceOutcomeOperation createOutcome(UUID accountId, String label, double amount, OutcomeCategory category, long timestamp) throws FinanceServiceException;

    List<FinanceIncomeOperation> listIncomes(FinanceIncomeSearchCriteria searchCriteria) throws FinanceServiceException;

    List<FinanceOutcomeOperation> listOutcomes(FinanceOutcomeSearchCriteria searchCriteria) throws FinanceServiceException;

    Balance getBalance(UUID accountId, TimeRange timeRange) throws FinanceServiceException;

}
