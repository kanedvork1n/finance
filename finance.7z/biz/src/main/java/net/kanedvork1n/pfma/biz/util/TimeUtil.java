package net.uniloftsky.pfma.biz.util;

import net.uniloftsky.pfma.biz.finance.filter.TimeRange;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;

public final class TimeUtil {

    public static final ZoneId ZONE_ID = ZoneId.systemDefault();
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public static TimeRange getTimeRange(String formattedDateFrom, String formattedDateTo) {
        LocalDate from = LocalDate.parse(formattedDateFrom, FORMATTER);
        LocalDate to = LocalDate.parse(formattedDateTo, FORMATTER);
        long startDate = from.atStartOfDay().atZone(ZONE_ID).toInstant().toEpochMilli();
        long endDate = to.atTime(23, 59, 59, 999_999_999).atZone(ZONE_ID).toInstant().toEpochMilli();
        return new TimeRange(startDate, endDate);
    }

    public static TimeRange getTimeRange(Month month, int year) {
        LocalDate localDateMonth = LocalDate.of(year, month, 1);
        long startDate = localDateMonth.atStartOfDay().atZone(ZONE_ID).toInstant().toEpochMilli();
        long endDate = localDateMonth.with(TemporalAdjusters.lastDayOfMonth()).atTime(23, 59, 59, 999_999_999).atZone(ZONE_ID).toInstant().toEpochMilli();
        return new TimeRange(startDate, endDate);
    }

    public static long getTimestamp(Month month, int year) {
        LocalDateTime now = LocalDateTime.now();
        if (now.getMonth().equals(month) && now.getYear() == year) {
            return now.atZone(ZONE_ID).toInstant().toEpochMilli();
        } else {
            TimeRange timeRange = TimeUtil.getTimeRange(month, year);
            return timeRange.getFrom();
        }
    }
}
