package net.uniloftsky.pfma.biz.account;

import net.anotheria.idbasedlock.IdBasedLock;
import net.anotheria.idbasedlock.IdBasedLockManager;
import net.anotheria.idbasedlock.SafeIdBasedLockManager;
import net.uniloftsky.pfma.biz.account.persistence.AccountEntity;
import net.uniloftsky.pfma.biz.account.persistence.AccountRepository;
import net.uniloftsky.pfma.biz.account.persistence.AccountSettingsEntity;
import net.uniloftsky.pfma.biz.account.persistence.AccountSettingsRepository;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

@Service
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;
    private final AccountSettingsRepository accountSettingsRepository;
    private final IdBasedLockManager<UUID> lockManager;

    public AccountServiceImpl(AccountRepository accountRepository, AccountSettingsRepository accountSettingsRepository) {
        this.accountRepository = accountRepository;
        this.accountSettingsRepository = accountSettingsRepository;
        this.lockManager = new SafeIdBasedLockManager<>();
    }

    @Override
    public Account createAccount(String email, AccountStatus... statuses) throws AccountServiceException {
        try {
            Optional<AccountEntity> optionalAccount = accountRepository.findByEmail(email);
            if (optionalAccount.isPresent()) {
                throw new AccountAlreadyExistsServiceException("Account with email: " + email + " already exists");
            }

            long currentTime = System.currentTimeMillis();
            AccountEntity entity = new AccountEntity();
            entity.setId(UUID.randomUUID());
            entity.setEmail(email);

            String statusesString = getStatusesString(Set.of(statuses));
            entity.setStatus(statusesString);

            entity.setRegistrationTimestamp(currentTime);
            entity.setCreationTimestamp(currentTime);
            entity = accountRepository.save(entity);
            return map(entity);
        } catch (AccountAlreadyExistsServiceException ex) {
            throw new AccountAlreadyExistsServiceException(ex.getMessage(), ex);
        } catch (Exception any) {
            throw new AccountServiceException("Cannot create account with email: " + email, any);
        }
    }

    @Override
    public Account getAccountById(UUID id) throws AccountServiceException {
        try {
            Optional<AccountEntity> optionalAccount = accountRepository.findById(id);
            if (optionalAccount.isEmpty()) {
                throw new AccountNotFoundServiceException("Account with id: " + id + " cannot be found");
            }

            return map(optionalAccount.get());
        } catch (AccountNotFoundServiceException ex) {
            throw new AccountNotFoundServiceException(ex.getMessage(), ex);
        } catch (Exception any) {
            throw new AccountServiceException("Cannot get account by id: " + id, any);
        }
    }

    @Override
    public Account getAccountByEmail(String email) throws AccountServiceException {
        try {
            Optional<AccountEntity> optionalAccount = accountRepository.findByEmail(email);
            if (optionalAccount.isEmpty()) {
                throw new AccountNotFoundServiceException("Account with email: " + email + " cannot be found");
            }

            return map(optionalAccount.get());
        } catch (AccountNotFoundServiceException ex) {
            throw new AccountNotFoundServiceException(ex.getMessage(), ex);
        } catch (Exception any) {
            throw new AccountServiceException("Cannot get account by email: " + email, any);
        }
    }

    @Override
    public Account updateAccount(Account toUpdate) throws AccountServiceException {
        validateAccountForUpdate(toUpdate);
        IdBasedLock<UUID> lock = lockManager.obtainLock(toUpdate.getId());
        lock.lock();
        try {
            Optional<AccountEntity> optionalAccount = accountRepository.findById(toUpdate.getId());
            if (optionalAccount.isEmpty()) {
                throw new AccountNotFoundServiceException("Cannot find account by id: " + toUpdate.getId());
            }

            long currentTime = System.currentTimeMillis();
            AccountEntity entity = optionalAccount.get();
            entity.setUpdatedTimestamp(currentTime);

            String statusesString = getStatusesString(toUpdate.getStatuses());
            entity.setStatus(statusesString);

            entity.setEmail(toUpdate.getEmail());
            entity = accountRepository.save(entity);
            return map(entity);
        } catch (AccountNotFoundServiceException ex) {
            throw new AccountNotFoundServiceException(ex.getMessage(), ex);
        } catch (Exception any) {
            throw new AccountServiceException("Cannot update account", any);
        } finally {
            lock.unlock();
        }
    }

    @Override
    public AccountSettings getAccountSettings(UUID accountId) throws AccountServiceException {
        try {
            Optional<AccountSettingsEntity> optionalSettings = accountSettingsRepository.findById(accountId);
            if (optionalSettings.isPresent()) {
                return map(optionalSettings.get());
            } else {
                AccountSettingsEntity createdSettings = initializeSettings(accountId);
                return map(createdSettings);
            }
        } catch (Exception any) {
            throw new AccountServiceException("Cannot get account settings for: " + accountId, any);
        }
    }

    @Override
    public AccountSettings updateNewsCheckSetting(UUID accountId, boolean newsCheck) throws AccountServiceException {
        IdBasedLock<UUID> lock = lockManager.obtainLock(accountId);
        lock.lock();
        try {
            Optional<AccountSettingsEntity> optionalSettings = accountSettingsRepository.findById(accountId);
            if (optionalSettings.isPresent()) {
                AccountSettingsEntity settingsEntity = optionalSettings.get();
                settingsEntity.setNewsCheck(newsCheck);

                long currentTime = System.currentTimeMillis();
                settingsEntity.setUpdatedTimestamp(currentTime);
                settingsEntity = accountSettingsRepository.save(settingsEntity);
                return map(settingsEntity);
            } else {
                AccountSettingsEntity createdSettings = initializeSettings(accountId);
                return map(createdSettings);
            }
        } catch (Exception any) {
            throw new AccountServiceException("Cannot update newsCheck setting for account: " + accountId, any);
        } finally {
            lock.unlock();
        }
    }

    private Account map(AccountEntity toMap) {
        Account result = new Account();
        result.setId(toMap.getId());
        result.setEmail(toMap.getEmail());

        Set<AccountStatus> statuses = parseStatuses(toMap.getStatus());
        result.setStatuses(statuses);

        result.setRegistrationTimestamp(toMap.getRegistrationTimestamp());
        result.setCreationTimestamp(toMap.getCreationTimestamp());
        result.setUpdatedTimestamp(toMap.getUpdatedTimestamp());
        return result;
    }

    private AccountSettings map(AccountSettingsEntity toMap) {
        AccountSettings result = new AccountSettings();
        result.setAccountId(toMap.getAccountId());
        result.setNewsCheck(toMap.isNewsCheck());
        result.setCreationTimestamp(toMap.getCreationTimestamp());
        result.setUpdatedTimestamp(toMap.getUpdatedTimestamp());
        return result;
    }

    private AccountSettingsEntity initializeSettings(UUID accountId) {
        AccountSettingsEntity createdSettings = new AccountSettingsEntity();
        createdSettings.setAccountId(accountId);
        createdSettings.setNewsCheck(false);

        long currentTime = System.currentTimeMillis();
        createdSettings.setCreationTimestamp(currentTime);
        return accountSettingsRepository.save(createdSettings);
    }

    private Set<AccountStatus> parseStatuses(String statusesString) {
        if (StringUtils.isEmpty(statusesString)) {
            throw new IllegalArgumentException("Cannot parse statuses because argument is empty or null");
        }

        Set<AccountStatus> result = new HashSet<>();
        String[] statusesArray = statusesString.split(",");
        for (String s : statusesArray) {
            AccountStatus status = AccountStatus.valueOf(s);
            result.add(status);
        }
        return result;
    }

    private String getStatusesString(Set<AccountStatus> statuses) {
        StringBuilder result = new StringBuilder();

        int index = 1;
        for (AccountStatus status : statuses) {
            if (index == statuses.size()) {
                result.append(status);
            } else {
                result.append(status).append(",");
            }
            index++;
        }

        return result.toString();
    }

    private void validateAccountForUpdate(Account account) {
        if (account == null) {
            throw new IllegalArgumentException("Cannot update account because parameter is null");
        }

        if (account.getId() == null) {
            throw new IllegalArgumentException("Cannot update account because id is null");
        }

        if (StringUtils.isEmpty(account.getEmail())) {
            throw new IllegalArgumentException("Cannot update account because email is null");
        }

        if (account.getStatuses() == null) {
            throw new IllegalArgumentException("Cannot update account because account statuses set is null");
        }
    }
}
