package net.uniloftsky.pfma.biz.authentication;

import org.springframework.security.core.AuthenticationException;

public class AuthenticationServiceException extends AuthenticationException {

    public AuthenticationServiceException(String message) {
        super(message);
    }

    public AuthenticationServiceException(String message, Throwable cause) {
        super(message, cause);
    }
}
