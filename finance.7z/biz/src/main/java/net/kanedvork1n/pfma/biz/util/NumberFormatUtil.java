package net.uniloftsky.pfma.biz.util;

public final class NumberFormatUtil {

    public static String formatCurrency(final double amount) {
        return String.format("%.2f", amount).replace(",", ".");
    }

}
