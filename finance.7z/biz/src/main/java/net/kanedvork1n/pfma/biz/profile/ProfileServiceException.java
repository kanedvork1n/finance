package net.uniloftsky.pfma.biz.profile;

public class ProfileServiceException extends Exception {

    public ProfileServiceException() {
    }

    public ProfileServiceException(String message) {
        super(message);
    }

    public ProfileServiceException(String message, Throwable cause) {
        super(message, cause);
    }
}
