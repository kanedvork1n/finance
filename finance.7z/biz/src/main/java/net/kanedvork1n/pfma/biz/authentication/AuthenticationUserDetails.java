package net.uniloftsky.pfma.biz.authentication;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.UUID;

public class AuthenticationUserDetails implements UserDetails {

    private final UUID accountId;
    private final String email;
    private final String encryptedPassword;

    public AuthenticationUserDetails(UUID accountId, String email, String encryptedPassword) {
        this.accountId = accountId;
        this.email = email;
        this.encryptedPassword = encryptedPassword;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return null;
    }

    @Override
    public String getPassword() {
        return this.encryptedPassword;
    }

    @Override
    public String getUsername() {
        return this.email;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

    public UUID getAccountId() {
        return accountId;
    }
}
