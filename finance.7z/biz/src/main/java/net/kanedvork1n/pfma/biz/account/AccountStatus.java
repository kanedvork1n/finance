package net.uniloftsky.pfma.biz.account;

public enum AccountStatus {

    REGISTERED, CONFIRMED

}
