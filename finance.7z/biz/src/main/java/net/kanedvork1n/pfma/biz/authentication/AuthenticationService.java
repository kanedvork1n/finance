package net.uniloftsky.pfma.biz.authentication;

import java.util.UUID;

public interface AuthenticationService {

    void setPassword(UUID accountId, String password) throws AuthenticationServiceException;

    String getEncodedPassword(UUID accountId) throws AuthenticationServiceException;

}
