package net.uniloftsky.pfma.biz.finance;

public class FinanceServiceException extends Exception {

    public FinanceServiceException() {
    }

    public FinanceServiceException(String message) {
        super(message);
    }

    public FinanceServiceException(String message, Throwable cause) {
        super(message, cause);
    }
}
