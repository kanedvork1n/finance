package net.uniloftsky.pfma.biz.finance;

import net.uniloftsky.pfma.biz.shared.FinanceOperationType;

public class FinanceIncomeOperation extends FinanceOperation {

    private static final FinanceOperationType CATEGORY_TYPE = FinanceOperationType.ADD;
    private IncomeCategory category;

    @Override
    public FinanceOperationType getType() {
        return CATEGORY_TYPE;
    }

    @Override
    public String getCategoryName() {
        return category.getTranslatedName();
    }

    @Override
    public String getCategoryTechnicalName() {
        return category.name();
    }

    public IncomeCategory getCategory() {
        return category;
    }

    public void setCategory(IncomeCategory category) {
        this.category = category;
    }

    @Override
    public String toString() {
        return "FinanceIncomeOperation{" +
                "category=" + category +
                '}';
    }
}
