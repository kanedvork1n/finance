package net.uniloftsky.pfma.biz.finance;

import net.uniloftsky.pfma.biz.shared.FinanceOperationType;

public class FinanceOutcomeOperation extends FinanceOperation {

    private static final FinanceOperationType CATEGORY_TYPE = FinanceOperationType.REMOVE;
    private OutcomeCategory category;

    @Override
    public FinanceOperationType getType() {
        return CATEGORY_TYPE;
    }

    @Override
    public String getCategoryName() {
        return category.getTranslatedName();
    }

    @Override
    public String getCategoryTechnicalName() {
        return category.name();
    }

    public OutcomeCategory getCategory() {
        return category;
    }

    public void setCategory(OutcomeCategory category) {
        this.category = category;
    }

    @Override
    public String toString() {
        return "FinanceOutcomeOperation{" +
                "category=" + category +
                '}';
    }
}
