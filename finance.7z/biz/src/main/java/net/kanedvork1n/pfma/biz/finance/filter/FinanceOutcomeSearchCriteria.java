package net.uniloftsky.pfma.biz.finance.filter;

import net.uniloftsky.pfma.biz.finance.OutcomeCategory;

import java.util.Collections;
import java.util.List;
import java.util.UUID;

public class FinanceOutcomeSearchCriteria {

    private UUID accountId;
    private TimeRange timeRange;
    private List<OutcomeCategory> includedCategories = Collections.emptyList();

    public FinanceOutcomeSearchCriteria(UUID accountId, TimeRange timeRange) {
        this.accountId = accountId;
        this.timeRange = timeRange;
    }

    public FinanceOutcomeSearchCriteria(TimeRange timeRange, List<OutcomeCategory> includedCategories) {
        this.timeRange = timeRange;
        this.includedCategories = includedCategories;
    }

    public UUID getAccountId() {
        return accountId;
    }

    public void setAccountId(UUID accountId) {
        this.accountId = accountId;
    }

    public TimeRange getTimeRange() {
        return timeRange;
    }

    public void setTimeRange(TimeRange timeRange) {
        this.timeRange = timeRange;
    }

    public List<OutcomeCategory> getIncludedCategories() {
        return includedCategories;
    }

    public void setIncludedCategories(List<OutcomeCategory> includedCategories) {
        this.includedCategories = includedCategories;
    }

    @Override
    public String toString() {
        return "FinanceOutcomeSearchCriteria{" +
                "accountId=" + accountId +
                ", timeRange=" + timeRange +
                ", includedCategories=" + includedCategories +
                '}';
    }

}
