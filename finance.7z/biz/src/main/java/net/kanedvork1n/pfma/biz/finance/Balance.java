package net.uniloftsky.pfma.biz.finance;

import java.util.Map;

public class Balance {

    private double balance;
    private Map<String, String> values;

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public Map<String, String> getValues() {
        return values;
    }

    public void setValues(Map<String, String> values) {
        this.values = values;
    }

    @Override
    public String toString() {
        return "Balance{" +
                "balance=" + balance +
                ", values=" + values +
                '}';
    }
}
