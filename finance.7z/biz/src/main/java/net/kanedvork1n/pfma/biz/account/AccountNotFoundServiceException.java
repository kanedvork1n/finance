package net.uniloftsky.pfma.biz.account;

public class AccountNotFoundServiceException extends AccountServiceException {

    public AccountNotFoundServiceException() {
    }

    public AccountNotFoundServiceException(String message) {
        super(message);
    }

    public AccountNotFoundServiceException(String message, Throwable cause) {
        super(message, cause);
    }
}
