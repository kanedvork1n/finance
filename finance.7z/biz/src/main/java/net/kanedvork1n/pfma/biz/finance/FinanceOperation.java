package net.uniloftsky.pfma.biz.finance;

import net.uniloftsky.pfma.biz.shared.FinanceOperationType;

import java.util.Objects;
import java.util.UUID;

public abstract class FinanceOperation {

    protected UUID id;
    protected UUID accountId;
    protected String label;
    protected double amount;
    protected long creationTimestamp;
    protected long updatedTimestamp;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public UUID getAccountId() {
        return accountId;
    }

    public void setAccountId(UUID accountId) {
        this.accountId = accountId;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public long getCreationTimestamp() {
        return creationTimestamp;
    }

    public void setCreationTimestamp(long creationTimestamp) {
        this.creationTimestamp = creationTimestamp;
    }

    public long getUpdatedTimestamp() {
        return updatedTimestamp;
    }

    public void setUpdatedTimestamp(long updatedTimestamp) {
        this.updatedTimestamp = updatedTimestamp;
    }

    public abstract FinanceOperationType getType();

    public abstract String getCategoryName();

    public abstract String getCategoryTechnicalName();

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FinanceOperation that = (FinanceOperation) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "FinanceOperation{" +
                "id=" + id +
                ", accountId=" + accountId +
                ", label='" + label + '\'' +
                ", amount=" + amount +
                ", creationTimestamp=" + creationTimestamp +
                ", updatedTimestamp=" + updatedTimestamp +
                '}';
    }
}
