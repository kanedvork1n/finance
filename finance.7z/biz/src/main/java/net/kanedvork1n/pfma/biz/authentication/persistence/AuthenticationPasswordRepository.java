package net.uniloftsky.pfma.biz.authentication.persistence;

import org.springframework.data.repository.CrudRepository;

import java.util.UUID;

public interface AuthenticationPasswordRepository extends CrudRepository<AuthenticationPasswordEntity, UUID> {
}
