package net.uniloftsky.pfma.biz.profile;

public class ProfileNotFoundServiceException extends ProfileServiceException {

    public ProfileNotFoundServiceException() {
    }

    public ProfileNotFoundServiceException(String message) {
        super(message);
    }

    public ProfileNotFoundServiceException(String message, Throwable cause) {
        super(message, cause);
    }
}
